"""
社交自动发布 —— 编排主流程
职责：
  1. 从 queue/ 取最旧的一个 .docx
  2. 解析英文正文 + 图片
  3. 依次发到各已启用平台（Facebook / LinkedIn），带重试
  4. 成功 -> 移到 posted/；失败 -> 移到 failed/ 并通知
  5. 全程写 logs/run.log，失败写 logs/notification.log
"""
import os
import sys
import json
import time
import shutil
from datetime import datetime

from word_parser import parse_docx
from facebook_publisher import post_to_facebook
from linkedin_publisher import post_to_linkedin
from video_publisher import post_video_to_facebook
from youtube_publisher import upload_video_to_youtube

BASE = os.path.dirname(os.path.abspath(__file__))
QUEUE = os.path.join(BASE, "queue")
POSTED = os.path.join(BASE, "posted")
FAILED = os.path.join(BASE, "failed")
LOGS = os.path.join(BASE, "logs")
VIDEOS_IN = os.path.join(BASE, "videos_in")
POSTED_VIDEOS = os.path.join(BASE, "posted_videos")
FAILED_VIDEOS = os.path.join(BASE, "failed_videos")

RETRY_ATTEMPTS = 3
RETRY_BACKOFF = 5  # 秒，每次翻倍


def ensure_dirs():
    for d in (QUEUE, POSTED, FAILED, LOGS, VIDEOS_IN, POSTED_VIDEOS, FAILED_VIDEOS):
        os.makedirs(d, exist_ok=True)


def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}][{level}] {msg}"
    print(line)
    try:
        with open(os.path.join(LOGS, "run.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def notify(subject, body):
    """目前写通知日志；如需邮件，可在 config.notify.email 配置后扩展。"""
    try:
        with open(os.path.join(LOGS, "notification.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now()}  {subject}\n{body}\n{'=' * 40}\n")
    except Exception:
        pass
    log(f"通知: {subject}")


def get_docx_files():
    """递归扫描 queue/ 下的所有 .docx（支持按日期命名的子文件夹）。"""
    results = []
    for root, dirs, files in os.walk(QUEUE):
        dirs[:] = [d for d in dirs if not d.startswith(".") and not d.startswith("~$")]
        for f in files:
            if f.lower().endswith(".docx") and not f.startswith("~$"):
                results.append(os.path.join(root, f))
    results.sort()  # 按路径升序 = 最旧优先
    return results


def _sibling_images(docx_path):
    """文档无内嵌图时，取同目录下的图片文件作为兜底配图。"""
    d = os.path.dirname(os.path.abspath(docx_path))
    out = []
    for f in sorted(os.listdir(d)):
        if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")) and not f.startswith("~$"):
            try:
                with open(os.path.join(d, f), "rb") as fh:
                    data = fh.read()
                out.append({"ext": f.rsplit(".", 1)[-1].lower(), "data": data})
            except Exception:
                pass
    return out


def post_with_retry(fn, name):
    last_err = None
    for i in range(RETRY_ATTEMPTS):
        try:
            result = fn()
            log(f"{name} 发布成功 -> {result}")
            return True, result
        except Exception as e:
            last_err = e
            log(f"{name} 第 {i + 1} 次尝试失败: {e}", "WARN")
            if i < RETRY_ATTEMPTS - 1:
                time.sleep(RETRY_BACKOFF * (i + 1))
    return False, str(last_err)


def process_docx(config):
    files = get_docx_files()
    if not files:
        log("队列为空，没有要发布的文档。")
        return False

    fname = os.path.basename(files[0])
    src = files[0]
    log(f"开始处理: {fname}")

    # 1) 解析
    try:
        parsed = parse_docx(src, config.get("word", {}).get("english_heading_keywords"))
    except Exception as e:
        log(f"解析 Word 失败: {e}", "ERROR")
        shutil.move(src, os.path.join(FAILED, fname))
        notify("解析失败", f"{fname}: {e}")
        return False

    if not parsed["english_text"]:
        log("未提取到英文正文，跳过。", "ERROR")
        shutil.move(src, os.path.join(FAILED, fname))
        notify("缺少英文正文", fname)
        return False

    log(f"解析完成: 正文 {len(parsed['english_text'])} 字, 图片 {len(parsed['images'])} 张")

    # 文档无内嵌图时，退而用同目录的图片文件作配图
    images = parsed["images"]
    if not images:
        sib = _sibling_images(src)
        if sib:
            images = sib
            log(f"文档无内嵌图，改用同目录图片 {len(sib)} 张")

    # 2) 发布（按启用状态）
    fb_cfg = config.get("facebook", {})
    li_cfg = config.get("linkedin", {})

    fb_configured = (
        fb_cfg.get("enabled", True)
        and not str(fb_cfg.get("access_token", "")).startswith("REPLACE")
        and str(fb_cfg.get("page_id", "")).strip()
    )
    li_configured = (
        li_cfg.get("enabled", True)
        and not str(li_cfg.get("access_token", "")).startswith("REPLACE")
        and str(li_cfg.get("organization_id", "")).strip()
    )

    posted_count = 0
    required_count = 0
    details = []

    if fb_configured:
        required_count += 1
        ok, res = post_with_retry(
            lambda: post_to_facebook(
                fb_cfg["page_id"], fb_cfg["access_token"],
                parsed["english_text"], images
            ), "Facebook"
        )
        details.append(f"Facebook: {'OK' if ok else 'FAIL ' + str(res)}")
        if ok:
            posted_count += 1
    else:
        log("Facebook 未启用或令牌/主页ID未填，跳过。")

    if li_configured:
        required_count += 1
        ok, res = post_with_retry(
            lambda: post_to_linkedin(
                li_cfg["organization_id"], li_cfg["access_token"],
                parsed["english_text"], images, li_cfg.get("api_version", "202406")
            ), "LinkedIn"
        )
        details.append(f"LinkedIn: {'OK' if ok else 'FAIL ' + str(res)}")
        if ok:
            posted_count += 1
    else:
        log("LinkedIn 未启用或令牌/组织ID未填，跳过。")

    # 3) 归档
    if required_count == 0:
        # 没有任何平台真正配置 -> 不发布也不移动，留在队列等配置好
        log("没有启用任何已配置的平台，文档留在队列不处理。", "WARN")
        notify("未配置发布平台", f"{fname}：Facebook/LinkedIn 均未配置，请先在 config.json 填写。")
        return False

    if posted_count == required_count:
        shutil.move(src, os.path.join(POSTED, fname))
        log(f"全部发布成功，已归档: {fname}")
        return True
    else:
        shutil.move(src, os.path.join(FAILED, fname))
        notify("发布未完全成功", f"{fname}\n  " + "\n  ".join(details))
        log(f"发布存在问题，已移入 failed/: {fname}", "ERROR")
        return False


def get_video_files():
    """递归扫描 videos_in/ 下的视频（支持按日期命名的子文件夹）。"""
    exts = (".mp4", ".mov", ".avi", ".mkv", ".webm")
    results = []
    for root, dirs, files in os.walk(VIDEOS_IN):
        dirs[:] = [d for d in dirs if not d.startswith(".") and not d.startswith("~$")]
        for f in files:
            if f.lower().endswith(exts) and not f.startswith("~$"):
                results.append(os.path.join(root, f))
    results.sort()  # 最旧优先
    return results


def process_videos(config):
    files = get_video_files()
    if not files:
        log("视频队列为空，没有要发布的视频。")
        return False

    fname = os.path.basename(files[0])
    src = files[0]
    log(f"开始处理视频: {fname}")

    # 1) 生成英文介绍（抽帧 + 视觉 API / 侧车 / 模板）
    try:
        from vision_intro import generate_intro
        description = generate_intro(src, config, log)
    except Exception as e:
        log(f"生成视频介绍失败: {e}", "ERROR")
        shutil.move(src, os.path.join(FAILED_VIDEOS, fname))
        notify("视频介绍生成失败", f"{fname}: {e}")
        return False
    log(f"视频介绍长度: {len(description)} 字")

    # 2) 发布（按启用状态）
    fb_cfg = config.get("facebook", {})
    fb_configured = (
        fb_cfg.get("enabled", True)
        and not str(fb_cfg.get("access_token", "")).startswith("REPLACE")
        and str(fb_cfg.get("page_id", "")).strip()
    )

    posted_count = 0
    required_count = 0
    details = []

    if fb_configured:
        required_count += 1
        ok, res = post_with_retry(
            lambda: post_video_to_facebook(
                fb_cfg["page_id"], fb_cfg["access_token"], src, description
            ), "Facebook视频"
        )
        details.append(f"Facebook视频: {'OK' if ok else 'FAIL ' + str(res)}")
        if ok:
            posted_count += 1
    else:
        log("Facebook 未配置或令牌/主页ID未填，跳过视频发布。")

    # YouTube 视频发布
    yt_cfg = config.get("youtube", {})
    yt_configured = (
        yt_cfg.get("enabled", False)
        and os.path.exists(os.path.join(BASE, "youtube_token.json"))
    )
    if yt_configured:
        required_count += 1
        # 标题优先用侧车 .yt.txt 首行，否则用文件名
        yt_base = os.path.splitext(src)[0]
        yt_title = None
        yt_sidecar = yt_base + ".yt.txt"
        if os.path.exists(yt_sidecar):
            try:
                with open(yt_sidecar, encoding="utf-8") as fh:
                    yt_title = fh.readline().strip() or None
            except Exception:
                pass
        ok, res = post_with_retry(
            lambda: upload_video_to_youtube(src, description, config, title=yt_title),
            "YouTube"
        )
        details.append(f"YouTube: {'OK' if ok else 'FAIL ' + str(res)}")
        if ok:
            posted_count += 1
    else:
        log("YouTube 未启用或令牌未生成，跳过视频发布。")

    li_cfg = config.get("linkedin", {})
    li_configured = (
        li_cfg.get("enabled", True)
        and not str(li_cfg.get("access_token", "")).startswith("REPLACE")
        and str(li_cfg.get("organization_id", "")).strip()
    )
    if li_configured:
        # LinkedIn 视频需分块上传到外部存储再建帖，流程更长，暂未实现
        log("LinkedIn 视频发布暂未实现，跳过（LinkedIn 图文仍可用）。")

    # 3) 归档
    if required_count == 0:
        log("没有启用任何已配置的平台，视频留在队列不处理。", "WARN")
        notify("未配置发布平台", f"{fname}：Facebook 未配置，请先在 config.json 填写。")
        return False

    if posted_count == required_count:
        # 连同侧车 .intro.txt / .yt.txt 一起归档
        base = os.path.splitext(src)[0]
        for sc in (base + ".intro.txt", base + ".yt.txt"):
            if os.path.exists(sc):
                shutil.move(sc, os.path.join(POSTED_VIDEOS, os.path.basename(sc)))
        shutil.move(src, os.path.join(POSTED_VIDEOS, fname))
        log(f"视频发布成功，已归档: {fname}")
        return True
    else:
        shutil.move(src, os.path.join(FAILED_VIDEOS, fname))
        notify("视频发布未完全成功", f"{fname}\n  " + "\n  ".join(details))
        log(f"视频发布存在问题，已移入 failed_videos/: {fname}", "ERROR")
        return False


_WEEKDAY_NAME = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def main(mode="auto"):
    """
    mode:
      "auto"   -> 按星期几分流：周一发文档+视频，周三发视频，周五发文档，其余日期两类都发
      "docs"   -> 只发文档
      "videos" -> 只发视频
      "both"   -> 两类都发
    """
    ensure_dirs()
    cfg_path = os.path.join(BASE, "config.json")
    if not os.path.exists(cfg_path):
        log("config.json 不存在，请先复制 config.example.json 并填写。", "ERROR")
        sys.exit(1)
    try:
        with open(cfg_path, encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        log(f"读取 config.json 失败: {e}", "ERROR")
        sys.exit(1)

    if mode == "auto":
        wd = datetime.now().weekday()  # 0=周一 ... 6=周日
        if wd == 2:
            log(f"今天{_WEEKDAY_NAME[wd]}：按排期只发视频")
            process_videos(config)
        elif wd == 0:
            log(f"今天{_WEEKDAY_NAME[wd]}：按排期发文档+视频")
            process_docx(config)
            process_videos(config)
        elif wd == 4:
            log(f"今天{_WEEKDAY_NAME[wd]}：按排期只发文档")
            process_docx(config)
        else:
            log(f"今天{_WEEKDAY_NAME[wd]}：非排期日，两类都处理（手动运行）")
            process_docx(config)
            process_videos(config)
    elif mode == "docs":
        process_docx(config)
    elif mode == "videos":
        process_videos(config)
    else:  # both
        process_docx(config)
        process_videos(config)


if __name__ == "__main__":
    main()
