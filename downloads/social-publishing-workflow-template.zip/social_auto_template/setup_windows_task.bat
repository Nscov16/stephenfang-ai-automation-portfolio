@echo off
chcp 65001 >nul
REM ============================================================
REM  社交自动发布 - 创建 Windows 定时任务（可移植版）
REM  用法：右键本文件 -> "以管理员身份运行"
REM  说明：
REM   - PYTHON：改成你机器上的 python（或虚拟环境 Scripts\python.exe）
REM   - SCRIPT：用 %~dp0 指向本 bat 同目录的 run_once.py，通常无需改
REM   - 周期固定 周一/三/五 17:00；改星期改 /d，改时间改 /st
REM ============================================================
set PYTHON=python
set SCRIPT=%~dp0run_once.py

echo 创建社交自动发布定时任务（每周一、三、五 17:00）
echo 脚本：%SCRIPT%
echo.

if not exist "%SCRIPT%" (
  echo [错误] 找不到 %SCRIPT%，请确认 run_once.py 与本 bat 在同一目录。
  pause
  exit /b 1
)

schtasks /create /tn "SocialAutoPublisher" /tr "\"%PYTHON%\" \"%SCRIPT%\"" /sc weekly /d MON,WED,FRI /st 17:00 /f

if %errorlevel%==0 (
  echo [成功] 定时任务 SocialAutoPublisher 已创建。
) else (
  echo [失败] 请以"管理员身份"运行本文件（右键 -> 以管理员身份运行）。
)
echo.
echo 手动立即运行一次：schtasks /run /tn "SocialAutoPublisher"
echo 用 taskschd.msc 查看/修改（改时间或手动运行）。
pause
