"""
Facebook 公共主页发布模块
使用 Graph API v26.0：
  - 先以 published=false 上传每张图片，拿到 media id
  - 再发 /feed，用 attached_media 关联多图
依赖：requests
"""
import json
import requests

GRAPH_API = "https://graph.facebook.com/v26.0"


def resolve_page_token(user_token, page_id):
    """
    用「用户令牌」换取该主页的「页面令牌」。
    页面令牌会随用户令牌的时效走，每次发布时重新换取，避免过期导致发不出。
    返回页面令牌字符串。
    """
    resp = requests.get(
        f"{GRAPH_API}/{page_id}",
        params={"fields": "access_token", "access_token": user_token},
        timeout=30,
    )
    data = resp.json()
    if "access_token" not in data:
        raise RuntimeError(f"换取页面令牌失败: {data}")
    return data["access_token"]


def _upload_photo(page_id, access_token, image):
    """上传单张图片（不单独发布），返回 photo id。"""
    resp = requests.post(
        f"{GRAPH_API}/{page_id}/photos",
        params={"access_token": access_token, "published": "false"},
        files={"source": (f"img.{image['ext']}", image["data"], f"image/{image['ext']}")},
        timeout=60,
    )
    data = resp.json()
    if "id" not in data:
        raise RuntimeError(f"FB 图片上传失败: {data}")
    return data["id"]


def post_to_facebook(page_id, access_token, message, images=None):
    """
    向 Facebook 公共主页发布一条帖子（文字 + 可选多图）。
    access_token 这里传入的是「用户令牌」，函数内部会自动换取页面令牌再发。
    返回帖子 id。
    """
    images = images or []
    page_token = resolve_page_token(access_token, page_id)
    media_ids = []
    for img in images:
        media_ids.append(_upload_photo(page_id, page_token, img))

    payload = {
        "access_token": page_token,
        "message": message,
    }
    if media_ids:
        payload["attached_media"] = json.dumps(
            [{"media_fbid": mid} for mid in media_ids]
        )

    resp = requests.post(
        f"{GRAPH_API}/{page_id}/feed",
        data=payload,
        timeout=60,
    )
    data = resp.json()
    if "id" not in data:
        raise RuntimeError(f"FB 发帖失败: {data}")
    return data["id"]
