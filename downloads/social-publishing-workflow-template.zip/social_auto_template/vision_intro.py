"""
视频英文介绍生成
流程：ffmpeg 抽帧 -> 视觉 API(Gemini / 字节豆包 ARK) 读懂视频 -> 英文介绍
依赖：imageio-ffmpeg(提供 ffmpeg 静态二进制), requests

优先级：
  1) 视频同名的 .intro.txt 侧车文件（你直接写的介绍，英文优先）
  2) 配置了 vision.api_key 时，调用视觉 API 看懂抽出的帧 -> 英文介绍
  3) 都没配 -> 模板兜底（不读内容，只给通用文案）
"""
import os
import re
import base64
import subprocess
import imageio_ffmpeg
import requests

DEFAULT_PROMPT = (
    "You are the social media manager for a precision mold & die manufacturing "
    "company ({company}). The attached frames are from a short factory/video clip. "
    "Write an engaging English post introduction for Facebook/LinkedIn based ONLY "
    "on what you see. Requirements:\n"
    "- 2-4 sentences describing the actual content (machines, process, product).\n"
    "- Confident, professional tone. No hype, no fabrication.\n"
    "- End with 4-6 relevant hashtags (e.g. #PrecisionManufacturing #CNCMachining).\n"
    "Output only the post text, no extra commentary or markdown fences."
)


def _ffmpeg_exe():
    return imageio_ffmpeg.get_ffmpeg_exe()


def _video_duration(video_path):
    exe = _ffmpeg_exe()
    p = subprocess.run([exe, "-i", video_path], capture_output=True, text=True, timeout=60)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", p.stderr or "")
    if not m:
        return 0.0
    h, mi, s = float(m.group(1)), float(m.group(2)), float(m.group(3))
    return h * 3600 + mi * 60 + s


def extract_frames(video_path, out_dir, num_frames=4):
    """均匀抽取 num_frames 帧（JPEG），返回帧文件路径列表。"""
    os.makedirs(out_dir, exist_ok=True)
    dur = _video_duration(video_path)
    if dur <= 0:
        dur = 1.0
    exe = _ffmpeg_exe()
    frames = []
    n = max(1, int(num_frames))
    for i in range(n):
        ts = dur * (i + 0.5) / n
        out = os.path.join(out_dir, f"frame_{i:02d}.jpg")
        subprocess.run(
            [exe, "-ss", f"{ts:.3f}", "-i", video_path, "-frames:v", "1",
             "-q:v", "2", "-y", out],
            capture_output=True, text=True, timeout=60,
        )
        if os.path.exists(out) and os.path.getsize(out) > 0:
            frames.append(out)
    return frames


def _b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def _call_gemini(frames, api_key, model, prompt):
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model}:generateContent?key={api_key}")
    parts = [{"text": prompt}]
    for fpath in frames:
        parts.append({"inline_data": {"mime_type": "image/jpeg", "data": _b64(fpath)}})
    body = {"contents": [{"role": "user", "parts": parts}]}
    r = requests.post(url, json=body, timeout=90)
    r.raise_for_status()
    data = r.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]


def _call_doubao(frames, api_key, model, prompt):
    url = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
    content = [{"type": "text", "text": prompt}]
    for fpath in frames:
        b64 = _b64(fpath)
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    body = {"model": model, "messages": [{"role": "user", "content": content}]}
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    r = requests.post(url, json=body, headers=headers, timeout=90)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]


def generate_intro(video_path, config, log=print):
    """生成视频的英文介绍文本。"""
    vcfg = config.get("videos", {})
    vdir = os.path.join(os.path.dirname(os.path.abspath(video_path)), "_frames")
    frames = extract_frames(video_path, vdir, int(vcfg.get("frame_count", 4)))
    log(f"已抽取 {len(frames)} 帧用于视觉解读")

    # 1) 侧车 .intro.txt 优先
    base = os.path.splitext(video_path)[0]
    sidecar = base + ".intro.txt"
    if os.path.exists(sidecar):
        txt = open(sidecar, encoding="utf-8").read().strip()
        if txt:
            log("使用附带 .intro.txt 作为介绍")
            return txt

    # 2) 视觉 API
    vision_cfg = config.get("vision", {})
    key = (vision_cfg.get("api_key") or "").strip()
    if key and not key.startswith("REPLACE"):
        provider = (vision_cfg.get("provider") or "gemini").lower()
        if provider == "gemini":
            model = vision_cfg.get("model") or "gemini-1.5-flash"
        else:
            model = vision_cfg.get("model") or "doubao-1.5-vision-pro"
        prompt = vision_cfg.get("prompt") or DEFAULT_PROMPT
        company = (config.get("company_name") or "your company").strip()
        if company:
            prompt = prompt.replace("{company}", company)
        try:
            if provider == "gemini":
                text = _call_gemini(frames, key, model, prompt)
            elif provider in ("doubao", "ark"):
                text = _call_doubao(frames, key, model, prompt)
            else:
                raise ValueError(f"不支持的 vision.provider: {provider}")
            text = text.strip().strip("`").strip()
            log("视觉 API 已生成英文介绍")
            return text
        except Exception as e:
            log(f"视觉 API 失败，转模板兜底: {e}", "WARN")

    # 3) 模板兜底
    name = os.path.splitext(os.path.basename(video_path))[0]
    company = (config.get("company_name") or "your company").strip()
    log("使用模板介绍（未配置视觉 API）")
    return (f"Check out our latest clip: {name}.\n"
            f"#PrecisionManufacturing #CNCMachining #MoldComponents #{company}")
