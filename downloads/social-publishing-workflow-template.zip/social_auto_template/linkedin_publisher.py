"""
LinkedIn 公司主页发布模块
使用 REST Posts API (/rest/posts)：
  - 图片先 initializeUpload 拿到 uploadUrl，PUT 二进制上传，得到 image URN
  - 再发 /rest/posts，author 用 urn:li:organization:{id}
必须带请求头：Authorization / LinkedIn-Version / X-Restli-Protocol-Version
依赖：requests
"""
import requests

LINKEDIN_API = "https://api.linkedin.com/rest"


def _headers(token, version):
    return {
        "Authorization": f"Bearer {token}",
        "LinkedIn-Version": version,
        "X-Restli-Protocol-Version": "2.0.0",
        "Content-Type": "application/json",
    }


def _upload_image(org_id, access_token, image, version):
    """初始化上传并 PUT 二进制，返回 image URN。"""
    init = requests.post(
        f"{LINKEDIN_API}/images?action=initializeUpload",
        headers=_headers(access_token, version),
        json={"initializeUploadRequest": {"owner": f"urn:li:organization:{org_id}"}},
        timeout=60,
    )
    init_data = init.json()
    try:
        upload_url = init_data["value"]["uploadUrl"]
        image_urn = init_data["value"]["image"]
    except (KeyError, TypeError):
        raise RuntimeError(f"LinkedIn 初始化图片上传失败: {init_data}")

    up = requests.put(
        upload_url,
        data=image["data"],
        headers={"Content-Type": f"image/{image['ext']}"},
        timeout=120,
    )
    if up.status_code >= 300:
        raise RuntimeError(f"LinkedIn 图片上传失败: {up.status_code} {up.text[:300]}")
    return image_urn


def post_to_linkedin(org_id, access_token, message, images=None, api_version="202406"):
    """
    向 LinkedIn 公司主页发布一条帖子（文字 + 可选单图）。
    返回帖子 URN（在 x-restli-id 响应头里）。
    """
    images = images or []
    image_urns = []
    for img in images:
        image_urns.append(_upload_image(org_id, access_token, img, api_version))

    body = {
        "author": f"urn:li:organization:{org_id}",
        "commentary": message,
        "visibility": "PUBLIC",
        "distribution": {
            "feedDistribution": "MAIN_FEED",
            "targetEntities": [],
            "thirdPartyDistributionChannels": [],
        },
        "lifecycleState": "PUBLISHED",
    }
    if image_urns:
        # LinkedIn 当前帖文直接关联单张图片
        body["content"] = {"media": {"id": image_urns[0]}}

    resp = requests.post(
        f"{LINKEDIN_API}/posts",
        headers=_headers(access_token, api_version),
        json=body,
        timeout=60,
    )
    if resp.status_code not in (200, 201):
        raise RuntimeError(f"LinkedIn 发帖失败: {resp.status_code} {resp.text[:400]}")
    return resp.headers.get("x-restli-id", "unknown")
