# 社交自动发布模板（Facebook + LinkedIn + YouTube）

一套**可移植、可复用**的队列式定时发布器：把 Word 图文和视频，自动发到 Facebook 公共主页、YouTube 频道、LinkedIn 公司主页。
本目录是**模板**——所有账号、令牌、业务名都已抽离成配置，填空即可在新机器 / 新业务上运行。

> 接手的技术细节、故障处理清单见同目录 **`AGENT.md`**（写给运维 agent 看）。

## 它能做什么
- **图文**：把 Word（.docx）丢进 `queue/`，自动提取**英文部分** + 内嵌图片，发到 Facebook（LinkedIn 可选）。
- **视频**：把视频丢进 `videos_in/`，自动抽帧 → 生成英文介绍 → 发到 Facebook + YouTube。
- **定时**：默认每周一/三/五 17:00 自动跑（周一图文+视频、周三视频、周五图文）。
- **容错**：失败重试，全过程写 `logs/run.log`。

## 目录结构
```
social_auto_template/
├── run_once.py              # 单次运行入口（定时任务调用）
├── publisher.py             # 编排：队列 / 重试 / 日志 / 分发
├── word_parser.py           # 抽 Word 英文正文 + 图片
├── facebook_publisher.py    # Facebook 发帖 / 视频
├── linkedin_publisher.py    # LinkedIn 图文（视频未实现）
├── video_publisher.py       # Facebook 视频上传
├── youtube_publisher.py     # YouTube 视频上传
├── youtube_auth.py          # YouTube OAuth 授权
├── vision_intro.py          # 视频抽帧 + 视觉 API 写英文介绍
├── refresh_token.py         # Facebook 短期令牌换长期
├── tools/                   # 运维脚本（删多余帖 / 修 YT 设置）
├── config.example.json      # 配置模板
├── requirements.txt         # 依赖
├── setup_windows_task.bat   # 一键建 Windows 定时任务
├── queue/  videos_in/  posted/  posted_videos/  failed/  failed_videos/  logs/   # 运行目录（空骨架）
└── AGENT.md                 # 给接手 agent 的速读
```

## 快速开始
1. **安装依赖**
   ```
   pip install -r requirements.txt
   ```
2. **建配置**：复制模板并填空
   ```
   cp config.example.json config.json
   ```
   把里面所有 `REPLACE_*` 换成你的真实值；`company_name` 填公司名（会自动替换介绍文案和标签里的 `{company}`）。
3. **授权平台**（详细步骤见 `AGENT.md`）
   - **Facebook**：开发者后台拿 App ID/Secret → Graph API Explorer 生成短期令牌 → `python refresh_token.py <短期令牌>` 换长期写入 config。
   - **YouTube**：Google Cloud 启用 YouTube Data API v3 → 下载 `client_secret.json` → `python youtube_auth.py --print-url` → 浏览器授权 → `python youtube_auth.py --code "<整串网址>"`。
   - **LinkedIn**：建 App、关联公司主页、申请 Share 权限审核通过 → 填 `access_token` + `organization_id`，`enabled` 改 `true`。
4. **放素材**
   - 图文 Word → `queue/`
   - 视频 → `videos_in/`（可选同名 `xxx.intro.txt` 写英文介绍、同名 `xxx.yt.txt` 覆盖 YouTube 标题）
5. **运行**
   - 手动跑一次：`python run_once.py`
   - 或建定时任务：右键 `setup_windows_task.bat` → 以管理员身份运行

## 配置字段速查（config.json）
| 字段 | 说明 |
|------|------|
| `company_name` | 公司名，`{company}` 占位会自动替换 |
| `facebook.*` | `page_id` / `access_token`(长期) / `app_id` / `app_secret` |
| `linkedin.*` | `enabled` / `organization_id` / `access_token` |
| `youtube.*` | `privacy`(public) / `made_for_kids`(false) / `title_source`(intro) / `default_tags` |
| `videos.*` | 输入/归档目录、抽帧数、视频扩展名 |
| `vision.*` | 视觉 API（可选）：`provider` / `api_key` / `model` / `prompt`（含 `{company}`） |
| `notify.*` | 失败通知方式（默认写日志，可改邮件） |

## 排期规则
| 星期 | 自动发 |
|------|--------|
| 周一 | 图文（FB）+ 视频（FB+YT） |
| 周三 | 仅视频（FB+YT） |
| 周五 | 仅图文（FB） |

## 常见问题
- **FB 发帖报 190/460**：令牌过期/作废 → 重新授权 + `refresh_token.py`。
- **YT 授权 403**：OAuth 同意屏没把账号加进「测试用户」。
- **视频介绍是模板文**：没填 `vision.api_key` 也没放 `.intro.txt`。
- **LinkedIn 失败**：确认 `enabled=true` 且 App 已通过审核；视频发 LinkedIn 暂不支持。

## 安全
- `config.json` / `client_secret.json` / `youtube_token.json` 含敏感凭据，**不要提交到公开仓库或外传**（已在 `.gitignore`）。
- 所有令牌都会过期，到期按上面步骤重授权即可。
