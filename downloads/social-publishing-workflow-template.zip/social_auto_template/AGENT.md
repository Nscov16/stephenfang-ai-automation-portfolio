# 社交自动发布模板 · 给接手 Agent 的速读

> 本目录是一套**可移植、可复用的社交发布器模板**。你（另一个 agent）拿到后，按下面步骤填空即可在新机器 / 新客户上跑起来。所有真实凭据都已抽离，业务名参数化。

## 它做什么
用官方 API，把用户提供的 **Word 图文** 和 **视频** 定时发到 **Facebook 公共主页 + YouTube 频道 + LinkedIn 公司主页**。
- **不自动生成文案**：内容由用户以 Word / 视频提供（视频介绍可由视觉 API 或 `.intro.txt` 侧车生成，但正文素材来自用户）。
- 队列式：Word 丢 `queue/`、视频丢 `videos_in/`，按 FIFO 取最旧的处理。

## 目录结构与各脚本职责
| 文件 | 职责 |
|------|------|
| `run_once.py` | 单次运行入口（定时任务调用），按星期几自动分流 |
| `publisher.py` | 编排核心：队列、重试、日志、通知、FB+YT+LinkedIn 分发 |
| `word_parser.py` | 解析 Word，抽**英文正文** + 内嵌图片 |
| `facebook_publisher.py` | FB 发图文/视频（发帖前用令牌运行时换取页面令牌） |
| `linkedin_publisher.py` | LinkedIn **图文**（视频未实现，代码内跳过） |
| `video_publisher.py` | FB 视频上传 |
| `youtube_publisher.py` | YouTube 视频上传（读 `youtube_token.json`） |
| `youtube_auth.py` | YouTube OAuth 授权：`--print-url` 出链接 / `--code` 换令牌 |
| `vision_intro.py` | 视频抽帧 + 视觉 API 写英文介绍（`.intro.txt` 侧车优先） |
| `refresh_token.py` | Facebook 短期令牌换长期（约 60 天）并写回 config |
| `tools/cleanup_extra_videos.py` | 删除多余的 FB/YT 视频帖（运维用） |
| `tools/fix_youtube_video.py` | 修正单条 YT 视频设置（公开 / 非儿童 / 标题） |
| `config.example.json` | 配置模板（复制为 `config.json` 填真实值） |
| `requirements.txt` | Python 依赖 |
| `setup_windows_task.bat` | 一键创建 Windows 定时任务（路径已参数化） |

## 上手步骤（按顺序执行）
1. **装依赖**：`pip install -r requirements.txt`（建议先建 venv）。
2. **建配置**：`cp config.example.json config.json`，把所有 `REPLACE_*` 填真实值；`company_name` 填公司名（会自动替换 prompt / 标签里的 `{company}`）。
3. **授权三平台**（外部账号操作需本人浏览器完成，令牌交换你代跑）：
   - **Facebook**：开发者后台拿 App ID/Secret → Graph API Explorer 生成**短期**用户令牌（勾 `pages_show_list`/`pages_manage_posts`/`pages_read_engagement`/`publish_video`）→ `python refresh_token.py <短期令牌>` 换长期并写入 config。
   - **YouTube**：Google Cloud 启用 **YouTube Data API v3** → 建「桌面应用」OAuth 凭据下载为 `client_secret.json` → `python youtube_auth.py --print-url` → 浏览器授权 → 回传 `python youtube_auth.py --code "<整串 localhost 网址>"`。
   - **LinkedIn**：建 App、关联公司主页、申请 Share 权限（MDP 审核 ~1–2 周）→ 把 `access_token` + `organization_id` 填 config，`enabled` 改 `true`。
4. **放素材**：Word → `queue/`；视频 → `videos_in/`（可附带同名 `.intro.txt` 写英文介绍、同名 `.yt.txt` 覆盖 YT 标题）。
5. **运行**：`python run_once.py`（手动立即跑一次）；或双击 `setup_windows_task.bat` 建每周一/三/五 17:00 定时任务。

## 关键约定
- **排期**：周一 = 图文 + 视频；周三 = 只视频；周五 = 只图文（均发 FB+YT；LinkedIn 仅图文）。
- **视频介绍优先级**：`.intro.txt` 侧车 > 视觉 API（填 `vision.api_key`）> 模板兜底文案。
- **令牌都会过期**：FB ~60 天（账号安全触发即废）、YT 测试态刷新令牌 ~7 天、LinkedIn ~60 天。
- **勿提交**：`config.json` / `client_secret.json` / `youtube_token.json`（已在 `.gitignore`）。

## 故障处理清单（接到报错先查这里）
- FB 报 `190`/`460`（session expired）→ 令牌作废，重做步骤 3 FB 授权 + `refresh_token.py`。
- YT 授权 `403` → OAuth 同意屏没把账号加进「测试用户」，加上重授权。
- YT 上传后删不了 `403` → scope 必须是 `youtube.force-ssl`（代码已内置）。
- LinkedIn 一直失败 → 确认 `enabled=true` 且 App 已通过 MDP 审核；视频发 LinkedIn 未实现。
- 视频介绍是模板/很泛 → 没填 `vision.api_key` 也没放 `.intro.txt`，二选一即可。
- 该发的内容没发 → 查 `queue/` 或 `videos_in/` 是否有文件、对应平台 `enabled` 是否 `true`；看 `logs/run.log`。

## 不要做的事
- 不要把 `config.json` / token 文件提交到公开仓库或外传。
- 不要改动核心逻辑去「自动生成文案」——用户明确要求内容由自己提供。
- 不要把真实账号信息写进 README / AGENT.md / 示例文件。

## 换业务复用
改 `config.company_name` 即可，prompt 与标签里的 `{company}` 自动替换；其余按需改 `youtube.default_tags`、`vision.prompt` 文案。无需改代码。
