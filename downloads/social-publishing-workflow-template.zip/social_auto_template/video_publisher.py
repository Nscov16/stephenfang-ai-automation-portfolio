"""
Facebook 视频发布模块（Graph API 视频专用接口 /{page_id}/videos）
依赖：requests；复用 facebook_publisher.resolve_page_token 换取页面令牌
"""
import os
import requests
from facebook_publisher import resolve_page_token

GRAPH_API = "https://graph.facebook.com/v26.0"


def post_video_to_facebook(page_id, access_token, video_path, description=""):
    """
    向 Facebook 公共主页发布一个视频（带文字介绍）。
    access_token 传入用户令牌，内部自动换取页面令牌。
    返回帖子 id。
    """
    page_token = resolve_page_token(access_token, page_id)
    with open(video_path, "rb") as f:
        resp = requests.post(
            f"{GRAPH_API}/{page_id}/videos",
            params={"access_token": page_token, "description": description},
            files={"file": (os.path.basename(video_path), f, "video/mp4")},
            timeout=300,
        )
    data = resp.json()
    if "id" not in data:
        raise RuntimeError(f"FB 视频发布失败: {data}")
    return data["id"]
