"""
YouTube 视频上传（官方 Data API v3，支持断点续传）。
依赖 youtube_token.json（由 youtube_auth.py 生成）。
"""
import os
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request

BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN_PATH = os.path.join(BASE, "youtube_token.json")
SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"]


def get_credentials():
    creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        with open(TOKEN_PATH, "w", encoding="utf-8") as f:
            f.write(creds.to_json())
    return creds


def derive_title(description, fallback_video_path):
    """用英文简介生成标题：取正文第一行里的第一句，最多 100 字符（按词截断）。"""
    if description:
        for line in description.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # 取第一句；破折号( — )也作为断句点，优先拿更干净的短语标题
            sent = line
            for sep in (" — ", ". ", "。", ".\n"):
                idx = line.find(sep)
                if 0 < idx < len(line):
                    sent = line[:idx]
                    break
            sent = sent.strip()
            if sent:
                if len(sent) > 100:
                    words = sent.split()
                    out = ""
                    for w in words:
                        if len(out) + len(w) + 1 <= 100:
                            out = (out + " " + w).strip()
                        else:
                            break
                    sent = out or sent[:100].rstrip()
                return sent
    # 兜底：文件名（不含扩展名）
    return os.path.splitext(os.path.basename(fallback_video_path))[0]


def upload_video_to_youtube(video_path, description, config, title=None, tags=None):
    if not os.path.exists(TOKEN_PATH):
        raise RuntimeError("YouTube 令牌不存在，请先运行 youtube_auth.py 完成授权")
    yt_cfg = config.get("youtube", {})
    privacy = yt_cfg.get("privacy", "private")
    made_for_kids = bool(yt_cfg.get("made_for_kids", False))
    category_id = yt_cfg.get("category_id", 28)
    default_tags = yt_cfg.get("default_tags", [])
    company = (config.get("company_name") or "").strip()
    if company:
        default_tags = [t.replace("{company}", company) for t in default_tags]
    title_source = (yt_cfg.get("title_source") or "intro").lower()

    if not title:
        # 优先级：config 指定 filename -> 用文件名；否则(默认 intro)从英文简介取
        if title_source == "filename":
            title = os.path.splitext(os.path.basename(video_path))[0]
        else:
            title = derive_title(description, video_path)

    creds = get_credentials()
    youtube = build("youtube", "v3", credentials=creds)

    body = {
        "snippet": {
            "title": title,
            "description": description or "",
            "tags": tags or default_tags,
            "categoryId": str(category_id),
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": made_for_kids,
        },
    }
    media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
    request = youtube.videos().insert(
        part="snippet,status", body=body, media_body=media
    )
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"  上传进度 {int(status.progress() * 100)}%")
    video_id = response.get("id")
    return video_id
