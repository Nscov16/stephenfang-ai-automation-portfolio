"""
FB 用户令牌续期脚本
====================
用 config.json 里已存的 facebook.app_id / app_secret，加上一个新的
「短期用户令牌」，通过 fb_exchange_token 换成约 60 天的长期用户令牌，
并自动写回 config.json 的 facebook.access_token。

用法：
  python refresh_token.py <短期用户令牌>

说明：
  - 短期令牌从 https://developers.facebook.com/tools/explorer/ 生成
    （选同一 App，勾上 pages_manage_posts、pages_read_engagement，发视频再加 publish_video）。
  - 本脚本只负责「换长期 + 写回」，不发任何帖子。
"""
import json
import os
import sys

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(HERE, "config.json")
GRAPH = "https://graph.facebook.com/v26.0"


def main():
    if len(sys.argv) < 2:
        print("用法: python refresh_token.py <短期用户令牌>")
        sys.exit(1)

    short = sys.argv[1].strip()
    if not short:
        print("错误：未提供短期令牌")
        sys.exit(1)

    with open(CONFIG, encoding="utf-8") as f:
        cfg = json.load(f)
    fb = cfg.get("facebook", {})
    app_id = fb.get("app_id")
    app_secret = fb.get("app_secret")
    if not (app_id and app_secret):
        print("config.json 缺少 facebook.app_id / app_secret，无法自动续期。")
        sys.exit(1)

    # 1) 短期 -> 长期(约60天) 用户令牌
    r = requests.get(
        f"{GRAPH}/oauth/access_token",
        params={
            "grant_type": "fb_exchange_token",
            "client_id": app_id,
            "client_secret": app_secret,
            "fb_exchange_token": short,
        },
        timeout=30,
    )
    data = r.json()
    if "access_token" not in data:
        print("换取失败:", data)
        sys.exit(1)
    long_token = data["access_token"]

    # 2) 写回 config.json
    fb["access_token"] = long_token
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

    print("OK：已换为长期令牌并写回 config.json")
    print("新令牌前 24 字符:", long_token[:24], "...")
    print("（约 60 天后到期，到时重复此操作即可）")


if __name__ == "__main__":
    main()
