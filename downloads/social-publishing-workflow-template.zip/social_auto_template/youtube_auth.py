"""
YouTube OAuth 一次性授权（桌面应用 / 复制粘贴流程，配合 loopback 重定向）。
前置：把从 Google Cloud 下载的 client_secret.json 放到本目录。

由于运行环境无法弹浏览器，采用「复制粘贴授权码」方式：

  python youtube_auth.py --print-url
     -> 打印授权链接（你在自己浏览器打开、登录、授权）
     -> 登录后浏览器会跳到 http://localhost 一个打不开的页面，
        请把地址栏里那一整串网址（含 code=...）复制发给我

  python youtube_auth.py --code "粘贴的整串网址或仅 code"
     -> 换成刷新令牌，保存为 youtube_token.json

成功后 youtube_token.json（含 refresh_token）供发布时自动读取。
"""
import os
import json
import argparse
from urllib.parse import urlparse, parse_qs

from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials

BASE = os.path.dirname(os.path.abspath(__file__))
CLIENT_SECRET = os.path.join(BASE, "client_secret.json")
TOKEN_PATH = os.path.join(BASE, "youtube_token.json")
VERIFIER_PATH = os.path.join(BASE, ".yt_verifier.json")
SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"]
REDIRECT_URI = "http://localhost"


def build_flow():
    if not os.path.exists(CLIENT_SECRET):
        raise SystemExit(
            f"找不到 {CLIENT_SECRET}，请先放入从 Google Cloud 下载的 client_secret.json"
        )
    return Flow.from_client_secrets_file(
        CLIENT_SECRET,
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI,
    )


def extract_code(raw):
    raw = raw.strip().strip('"')
    if raw.startswith("http://") or raw.startswith("https://"):
        q = parse_qs(urlparse(raw).query)
        if "code" in q:
            return q["code"][0]
    return raw


def run_auth(auth_code):
    flow = build_flow()
    # 复用 print-url 时保存的 PKCE code_verifier，否则会报 Missing code verifier
    if os.path.exists(VERIFIER_PATH):
        try:
            with open(VERIFIER_PATH, encoding="utf-8") as f:
                flow.code_verifier = json.load(f).get("code_verifier")
        except Exception:
            pass
    flow.fetch_token(code=auth_code)
    creds = flow.credentials
    with open(TOKEN_PATH, "w", encoding="utf-8") as f:
        f.write(creds.to_json())
    print(f"已保存令牌到 {TOKEN_PATH}")
    print("refresh_token 存在:", bool(creds.refresh_token))
    # 用完后清掉一次性 verifier
    if os.path.exists(VERIFIER_PATH):
        os.remove(VERIFIER_PATH)


def print_url():
    flow = build_flow()
    auth_url, _ = flow.authorization_url(prompt="consent", access_type="offline")
    # 保存 PKCE verifier，供后续 --code 复用
    with open(VERIFIER_PATH, "w", encoding="utf-8") as f:
        json.dump({"code_verifier": flow.code_verifier}, f)
    print("=== 请复制下面的链接，用拥有目标 YouTube 频道的 Google 账号在浏览器打开并授权 ===")
    print(auth_url)
    print("=== 登录授权后，浏览器会跳到 http://localhost 一个打不开的页面；")
    print("=== 请复制地址栏里那一整串网址（含 code=...）发给我 ===")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--print-url", action="store_true", help="仅打印授权链接")
    p.add_argument("--code", help="授权后得到的 code 或整串重定向网址")
    args = p.parse_args()
    if args.print_url:
        print_url()
    elif args.code:
        run_auth(extract_code(args.code))
    else:
        print("用法：")
        print("  python youtube_auth.py --print-url         # 打印授权链接")
        print("  python youtube_auth.py --code <code或网址>  # 完成授权")
