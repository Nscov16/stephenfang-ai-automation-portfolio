"""
Word 文档解析模块
功能：
  1. 自动识别并提取文档中的英文版正文（支持"整篇英文 + 整篇中文"上下排列的双语文档）
  2. 提取文档内所有图片二进制（用于随帖发布）
依赖：python-docx
"""
import os
import re

IMAGE_RELTYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"

_CONTENT_EXT = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/gif": "gif",
    "image/bmp": "bmp",
    "image/tiff": "tiff",
    "image/x-emf": "emf",
    "image/x-wmf": "wmf",
}

_CN_RE = re.compile(r'[\u4e00-\u9fff]')


def _has_chinese(s):
    return bool(_CN_RE.search(s))


def _chinese_ratio(s):
    if not s:
        return 0.0
    cn = sum(1 for c in s if '\u4e00' <= c <= '\u9fff')
    return cn / max(1, len(s))


def parse_docx(path, english_keywords=None):
    """
    解析一个 .docx 文件。
    返回 dict: {"title", "english_text", "images"}
    """
    from docx import Document
    doc = Document(path)
    title, english_text = _extract_english(doc)
    if not title:
        title = os.path.splitext(os.path.basename(path))[0]
    images = _extract_images(doc)
    return {"title": title, "english_text": english_text, "images": images}


def _extract_english(doc):
    """按一级标题(Heading 1 / Title)分块，选中文占比最低的块作为英文版。"""
    blocks = []
    cur = None
    for p in doc.paragraphs:
        text = (p.text or "").strip()
        style = p.style.name if p.style else ""
        is_h1 = style.startswith("Heading 1") or style == "Title"
        if is_h1 and text:
            if cur is not None:
                blocks.append(cur)
            cur = {"title": text, "lines": []}
        else:
            if cur is None:
                cur = {"title": None, "lines": []}
            if text:
                cur["lines"].append(text)
    if cur is not None:
        blocks.append(cur)

    if blocks:
        best = None
        for b in blocks:
            ratio = _chinese_ratio(" ".join(b["lines"]))
            # 中文占比越低越像英文；占比相同时行数多者优先
            key = (ratio, -len(b["lines"]))
            if best is None or key < best[0]:
                best = (key, b)
        b = best[1]
        body = "\n\n".join(b["lines"]).strip()
        if body:
            return (b["title"] or "", body)

    # 兜底：全篇语言检测，收集开头连续英文段；若中文在前则取尾部英文段
    paras = [(p.text or "").strip() for p in doc.paragraphs]
    paras = [x for x in paras if x]
    if not paras:
        return ("", "")
    first_cn = next((i for i, t in enumerate(paras) if _has_chinese(t)), None)
    if first_cn is None:
        return ("", "\n\n".join(paras))
    if first_cn > 0:
        return ("", "\n\n".join(paras[:first_cn]))
    last_cn = max(i for i, t in enumerate(paras) if _has_chinese(t))
    if last_cn + 1 < len(paras):
        return ("", "\n\n".join(paras[last_cn + 1:]))
    return ("", "")


def _extract_images(doc):
    """提取文档内所有图片的二进制数据。"""
    images = []
    try:
        rels = doc.part.rels
    except Exception:
        return images
    for rel in rels.values():
        if getattr(rel, "reltype", "") != IMAGE_RELTYPE:
            continue
        try:
            blob = rel.target_part.blob
            ct = getattr(rel.target_part, "content_type", "image/png")
            ext = _CONTENT_EXT.get(ct, ct.split("/")[-1] if "/" in ct else "bin")
            images.append({"ext": ext, "data": blob})
        except Exception:
            continue
    return images


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        r = parse_docx(sys.argv[1])
        print("标题:", r["title"])
        print("英文正文长度:", len(r["english_text"]))
        print("图片数量:", len(r["images"]))
        print("---- 英文正文前 600 字 ----")
        print(r["english_text"][:600])
