"""
修正已发布的单个 YouTube 视频的设置（不改内容）：
  - 隐私: public
  - 非面向儿童(selfDeclaredMadeForKids=false)
  - 标题: 从英文简介(.intro.txt)取第一句
用法：python fix_youtube_video.py <videoId> [intro_txt_path]
"""
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))

from youtube_publisher import get_credentials, derive_title
from googleapiclient.discovery import build


def main():
    if len(sys.argv) < 2:
        print("用法: python fix_youtube_video.py <videoId> [intro_txt_path]")
        sys.exit(1)
    video_id = sys.argv[1].strip()
    intro_path = sys.argv[2] if len(sys.argv) > 2 else None

    creds = get_credentials()
    yt = build("youtube", "v3", credentials=creds)

    cur = yt.videos().list(part="snippet,status", id=video_id).execute()
    if not cur.get("items"):
        print("找不到该视频:", video_id)
        sys.exit(1)
    item = cur["items"][0]
    sn = item["snippet"]
    st = item["status"]
    print(f"[当前] 标题: {sn.get('title')!r} | 隐私: {st.get('privacyStatus')} | "
          f"madeForKids: {st.get('selfDeclaredMadeForKids')}")

    desc = sn.get("description", "")
    if intro_path and os.path.exists(intro_path):
        desc = open(intro_path, encoding="utf-8").read().strip()
    new_title = derive_title(desc, "video.mp4")

    new_snippet = {
        "title": new_title,
        "description": sn.get("description", ""),
        "categoryId": sn.get("categoryId", "28"),
        "tags": sn.get("tags", []),
    }
    if sn.get("defaultLanguage"):
        new_snippet["defaultLanguage"] = sn["defaultLanguage"]
    if sn.get("defaultAudioLanguage"):
        new_snippet["defaultAudioLanguage"] = sn["defaultAudioLanguage"]

    new_status = {
        "privacyStatus": "public",
        "selfDeclaredMadeForKids": False,
    }

    yt.videos().update(
        part="snippet,status",
        body={"id": video_id, "snippet": new_snippet, "status": new_status},
    ).execute()
    print(f"[新标题] {new_title!r}")

    v = yt.videos().list(part="snippet,status", id=video_id).execute()["items"][0]
    print(f"[验证] 标题: {v['snippet']['title']!r} | 隐私: {v['status']['privacyStatus']} | "
          f"madeForKids: {v['status']['selfDeclaredMadeForKids']}")


if __name__ == "__main__":
    main()
