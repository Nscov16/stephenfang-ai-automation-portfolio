"""
一次性清理脚本：只保留 蓝v1，删除蓝v2 / 蓝字1 在两个平台的帖子，
并把 videos_in/ 里重复的 蓝字1 移到队列外。
"""
import os
import shutil
import json
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
GRAPH_API = "https://graph.facebook.com/v26.0"

# 要删除的帖子（保留 蓝v1 不动）
FB_POSTS = {
    "蓝v2.mp4": "2288054828624524",
    "蓝字1.mp4": "1020952907415665",
}
YT_VIDEOS = {
    "蓝v2.mp4": "FEXZ6tzdyQI",
    "蓝字1.mp4 (本次批量)": "xbPNSrF2vzY",
    "蓝字1.mp4 (旧私密测试版)": "e2-BZcyV2kc",
}


def load_config():
    with open(os.path.join(BASE, "config.json"), encoding="utf-8") as f:
        return json.load(f)


def delete_fb(post_id, page_token):
    resp = requests.delete(
        f"{GRAPH_API}/{post_id}",
        params={"access_token": page_token},
        timeout=30,
    )
    return resp.status_code, resp.text


def delete_yt(video_id, creds):
    from googleapiclient.discovery import build
    youtube = build("youtube", "v3", credentials=creds)
    youtube.videos().delete(id=video_id).execute()


def main():
    config = load_config()
    fb_cfg = config["facebook"]
    user_token = fb_cfg["access_token"]
    page_id = fb_cfg["page_id"]

    # 取页面令牌（用于删帖）——若令牌已失效则跳过 FB，先保证 YT 删除
    from facebook_publisher import resolve_page_token
    page_token = None
    try:
        page_token = resolve_page_token(user_token, page_id)
        print(f"[FB] 页面令牌已获取 (page_id={page_id})")
    except Exception as e:
        print(f"[FB] 令牌失效，无法删除 FB 帖子: {e}")

    print("\n===== 删除 Facebook 帖子 =====")
    if page_token:
        for name, pid in FB_POSTS.items():
            try:
                code, txt = delete_fb(pid, page_token)
                ok = code == 200
                print(f"  {name:12s} post={pid} -> HTTP {code} {'OK' if ok else txt[:200]}")
            except Exception as e:
                print(f"  {name:12s} post={pid} -> 异常 {e}")
    else:
        for name, pid in FB_POSTS.items():
            print(f"  {name:12s} post={pid} -> 跳过（FB 令牌失效）")

    print("\n===== 删除 YouTube 视频 =====")
    try:
        from youtube_publisher import get_credentials
        creds = get_credentials()
        for name, vid in YT_VIDEOS.items():
            try:
                delete_yt(vid, creds)
                print(f"  {name:22s} video={vid} -> 已删除 OK")
            except Exception as e:
                msg = str(e)
                # 404 = 已不存在，视为达成目标
                if "404" in msg:
                    print(f"  {name:22s} video={vid} -> 已不存在(404)，忽略")
                else:
                    print(f"  {name:22s} video={vid} -> 异常 {msg[:200]}")
    except Exception as e:
        print(f"  YouTube 令牌/服务异常: {e}")

    print("\n===== 挪走 videos_in 里重复的 蓝字1 =====")
    dup_dir = os.path.join(BASE, "_unpublished_dupes")
    os.makedirs(dup_dir, exist_ok=True)
    for fn in ("蓝字1.mp4", "蓝字1.intro.txt"):
        src = os.path.join(BASE, "videos_in", fn)
        if os.path.exists(src):
            dst = os.path.join(dup_dir, fn)
            shutil.move(src, dst)
            print(f"  已移出队列: videos_in/{fn} -> _unpublished_dupes/{fn}")
        else:
            print(f"  (不在队列中，跳过) {fn}")

    print("\n完成。保留的帖子：蓝v1 -> FB 1749384716255351 / YT G4WEuYNH0r0")


if __name__ == "__main__":
    main()
