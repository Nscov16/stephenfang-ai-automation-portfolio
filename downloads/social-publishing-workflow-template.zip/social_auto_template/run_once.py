"""
入口：供 Windows 定时任务 / WorkBuddy 定时任务调用。
默认按星期几自动分流（周一=文档+视频，周三=视频，周五=文档）。

手动运行可选参数：
  python run_once.py            # 自动按当天星期分流
  python run_once.py --docs     # 强制只发文档
  python run_once.py --videos   # 强制只发视频
  python run_once.py --both     # 两类都发
"""
import sys
from publisher import main

if __name__ == "__main__":
    args = sys.argv[1:]
    mode = "auto"
    if "--docs" in args:
        mode = "docs"
    elif "--videos" in args:
        mode = "videos"
    elif "--both" in args:
        mode = "both"
    main(mode)
