@echo off
REM 一键安装：建 venv 并安装依赖（python-docx）
REM 用法：双击本文件，或命令行执行 setup.bat
cd /d "%~dp0"
where python >nul 2>nul || (echo 未找到 python，请先安装 Python 3.10+ 并加入 PATH & pause & exit /b 1)
if not exist venv (
  echo 创建虚拟环境 venv ...
  python -m venv venv
)
call venv\Scripts\activate.bat
echo 安装依赖 python-docx ...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo 安装完成。请编辑 config.json 填入你的 WordPress 站点信息。
echo 运行示例：
echo   venv\Scripts\python draft_run\run_drafts.py
echo   venv\Scripts\python draft_run\gen_zh_output.py
echo   venv\Scripts\python draft_run\build_word.py
pause
