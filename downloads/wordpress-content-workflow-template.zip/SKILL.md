---
name: wp-auto-content-pipeline
description: 从一张产品图自动生成多份内容并发布/打包的 WordPress 流水线（自包含、可移植到任意 agent/站点）。触发场景：用户有产品图需要用 AI 写成英文文章发到 WordPress（带特色图、直接发布），同时生成中文站手动发布包（Word 纯文字+独立图片，按日期分类）与英文存档 Word（每篇独立、英文-only、不含图、独立图片）。也适用于「给缺特色图的 WP 草稿批量补图」「搭建每周定时的自动发文 agent」。整包 BASE 从脚本路径自动推导，拷到任意机器即可用。
---

# WordPress 自动内容流水线（wp-auto-content-pipeline）

把「一张产品图 → 多份内容」固定成**自包含、可移植**的闭环。整包不写死任何绝对路径，所有脚本的 `BASE` 都从自身路径推导（`os.path.dirname(os.path.dirname(__file__))`），拷到任意机器/agent 直接可用。

## 产出三件套（一次处理 1 张图）

1. **英文文章** → 发到 WordPress（自动上传图、设为特色图片；`default_status` 决定草稿还是直发）。
2. **中文文章** → 中企动力式手动发布包：`output/zhongqi/YYYY-MM-DD/<标题>.docx`（纯文字，不嵌图）+ 同目录独立图片文件。正文硬上限 **≤400 中文字**。
3. **英文存档 Word** → `output/bilingual/YYYY-MM-DD/<slug>.docx`：**一篇一档**、英文-only、**不含图**，原图位改为一行图片引用说明；独立产品图同目录。正文硬上限 **≤400 英文词**。

全部按运行日期分类，三套幂等日志防止重复发文/重复生成。

## 何时用

- 提到「WordPress 自动发文 / 定时发文」「产品图写文章」「英文存档 Word / 中企动力发布包 / 手动发布包」。
- 需要「给一批缺特色图的 WP 草稿批量补图（不改状态、不发布）」→ 用 `draft_run/fix_featured_drafts.py`。

## 目录布局（skill 根即 BASE）

```
wp-auto-content-pipeline/
├── SKILL.md
├── config.json            # 站点配置（首次使用前必须改成真实值）
├── requirements.txt       # python-docx
├── setup.bat / setup.sh   # 一键建 venv + 装依赖
├── _repair_docx_cjk.py    # 工具：清理 docx 残留（CJK/裸文件名/重复引用），可移植
├── _sweep_docx_residue.py # 工具：深度扫描 docx 残留，可移植
├── draft_run/
│   ├── run_drafts.py        # 英文发 WP（带特色图）
│   ├── gen_zh_output.py     # 中企动力中文包（Word 纯文字 + 独立图片）
│   ├── build_word.py        # 英文存档 Word（每篇独立、英文-only、不含图）
│   ├── fix_featured_drafts.py  # 给缺特色图草稿补图（--apply 才写）
│   ├── draft_articles.json      # 英文文章（由写文章步骤生成）
│   ├── draft_articles_zh.json   # 中文文章（由写文章步骤生成，≤400 中文字）
│   ├── draft_articles_en_word.json  # 英文精简版（由写文章步骤生成，≤400 英文词）
│   ├── media_map.json           # img_rel -> WP 媒体 ID（防同名撞车核心）
│   └── created_log.json         # 英文已发幂等日志
├── materials/
│   ├── inbox/        # 待处理产品图放这里（递归扫描，含子目录）
│   └── processed/    # 已处理图片归档处
└── output/
    ├── zhongqi/YYYY-MM-DD/   # 中文发布包（_gen_log.json 幂等）
    └── bilingual/YYYY-MM-DD/ # 英文存档 Word（_bilingual_log.json 幂等）
```

> **可移植关键**：所有脚本开头都是 `HERE = os.path.dirname(os.path.abspath(__file__)); BASE = os.path.dirname(HERE)`，无任何机器专属绝对路径。

## 前置条件

- Python 3.10+（首次用 `setup.bat` / `setup.sh` 建 venv 并装 python-docx）。
- WordPress 开启 **Application Password**（用户→安全→应用密码），用 `用户:应用密码` 做 Basic Auth。
- 首次使用前：编辑 `config.json` 填 `site_url` / `username` / `application_password`；`default_category_id` 按站点分类 ID 调整（默认 1=Blog）；`default_status` 用 `"publish"`（直发）或 `"draft"`（仅建草稿）。

## 写作协议（LLM 必须执行的关键步骤）

脚本只负责「发布/打包」。**文章由 LLM 生成**，产出三个 JSON 文件后才能跑脚本。每篇 1 张图、覆盖写入（不要累积历史）：

### 1. 扫描素材
递归扫 `materials/inbox/`，挑出**未处理**的图片。判重依据：
- 英文已发 → `draft_run/created_log.json` 的 key（img_rel）
- 中文已生成 → `output/zhongqi/_gen_log.json` 的 key
- 英文存档已生成 → `output/bilingual/_bilingual_log.json` 的 key
- 媒体已上传 → `draft_run/media_map.json` 的 key

同一个 img_rel 在上述任一日志里出现就跳过（幂等）。

### 2. 英文完整版 `draft_articles.json`（供 WordPress，保持完整长度）
数组，每篇：
```json
{
  "img_rel": "产品图资产/PP可立袋/尺寸参照图/xxx.png",
  "title": "PP Preform Mould Dimension Reference for IV Bag Hanger Integration",
  "html": "<h2>Overview</h2><p>...</p><p>__IMG__</p><h3>Key Design</h3><ul><li>...</li></ul><table>...</table>"
}
```
- `img_rel`：图片相对 `materials/inbox/` 的路径（含子目录，用 `/`）。
- `title`：英文标题（专业技法风、面向海外采购，en-US），准确含英文关键词。
- `html`：HTML 片段，**图片用 `__IMG__` 占位符**（脚本替换成 `<figure><img></figure>`）。允许标签：`h2 h3 p ul/li strong table/tr/td br`。
- 英文 SEO 关键词参考知识库「第十二节 关键词矩阵」（产品词放标题/首段，H2 用知识型问句）。
- **一篇图 → 一篇文**。

### 3. 中文精简版 `draft_articles_zh.json`（供中企动力，≤400 中文字）
数组，每篇 `img_rel` 须与英文那篇**相同**：
```json
{
  "img_rel": "产品图资产/PP可立袋/尺寸参照图/xxx.png",
  "title": "PP 可立袋输液瓶吊环一体瓶坯模具：尺寸参照图中的腔数、占地与容差策略",
  "html": "<h2>概述</h2><p>...</p><p>__IMG__</p><h3>关键设计</h3><ul><li>...</li></ul>"
}
```
- 中文须是**面向中文客户的原生重写**（非机翻），自然植入中文关键词与品牌背书。
- **正文 ≤400 中文字**（标题不计入；`gen_zh_output.py` 带 `MAX_CHARS=400` 硬截断兜底）。
- 省字数技巧：段落连写去掉 `</p>\n\n<h2>` 间空白，可多塞 ~30 字。
- 中文 SEO/选题参考知识库「第十二节 12.2」。

### 4. 英文精简版 `draft_articles_en_word.json`（供英文存档，≤400 英文词）
数组，结构与英文完整版相同，但**正文 ≤400 英文词**（`build_word.py` 带 `MAX_WORDS=400` 硬截断兜底）：
```json
{
  "img_rel": "产品图资产/PP可立袋/尺寸参照图/xxx.png",
  "title": "PP Preform Mould Dimension Reference for IV Bag Hanger Integration",
  "html": "<h2>Overview</h2><p>...</p><p>__IMG__</p>..."
}
```
- 若无此文件，`build_word.py` 自动回退读 `draft_articles.json` 完整版（按 400 词截断），不影响运行。

### 5. 运行（顺序）
```bash
python draft_run/run_drafts.py        # 英文发 WP + 写 media_map + 写 created_log
python draft_run/gen_zh_output.py     # 中文发布包（按日期，图片从 WP 媒体库按 id 精确下载）
python draft_run/build_word.py        # 英文存档 Word（每篇独立，图片同上）
```
> `run_drafts.py` 跑完后会更新 `media_map.json`（img_rel→media_id），中企动力与存档脚本**必须**在它之后跑，才能精确取到对应线上图片。

### 6. 批量补特色图（不影响发布）
```bash
python draft_run/fix_featured_drafts.py          # dry-run，仅打印映射
python draft_run/fix_featured_drafts.py --apply  # 真正写入（只改 featured_media，status 保持 draft）
```

## 踩坑清单（务必遵守，否则会出错/发错图/出残留）

1. **LiteSpeed 必须带 `User-Agent`**：所有 WP 请求头加 `"User-Agent": "Mozilla/5.0"`，否则 403。
2. **POST JSON 必须显式 `Content-Type: application/json; charset=utf-8`**：否则 urllib 默认 `x-www-form-urlencoded`，WP 收不到 title/content（报错 `empty_content`）。`run_drafts.py` 已内置。
3. **图片按 `media_id` 取，绝不靠本地文件名**：早期示例图都叫 `clean.png`，本地同名撞车导致用了错图。现已改为按 `media_map` 的 media_id 从 WP 媒体库下载，彻底规避。换图/加新图时先 `run_drafts.py` 上传建 id。
4. **三套幂等日志 + media_map** 防止重复发文、重复生成、重复上传。重跑安全。
5. **中企动力 Word 不嵌图**：图片作为独立文件放同目录，Word 正文只加一行「配套图片见同目录文件：xxx」。
6. **英文存档 Word = 一篇一档、英文-only、不含图**：旧版曾把中英双版+内嵌图合并进 `articles_YYYY-MM-DD.docx`，已废弃。腾讯文档预览会把 `clean.png` 这类**裸文件名文本**误渲染成缩略图——若发现 docx 有「残留小图」，用 `_sweep_docx_residue.py` 扫描、用 `_repair_docx_cjk.py` 清理。
7. **CJK 清理陷阱**：清理中文残切记对**整段文字合并处理再回写为单个 run**，否则跨 run 边界空格丢失（出现 `Thepipette tip coreforms` 破词）。`_repair_docx_cjk.py` 已按此实现。

## docx 残留自检与修复（复用工具）

```bash
python _sweep_docx_residue.py                 # 扫描 output/bilingual + output/zhongqi
python _sweep_docx_residue.py <目录>           # 只扫指定目录
python _repair_docx_cjk.py [目录]              # 清理 CJK/裸文件名/重复引用（默认扫 output/bilingual）
```
> 建议重大改动前先备份 docx，再跑修复。

## 定时任务模板（每周一/三/五 9:00 自动成文+发布一篇）

在目标 agent 上建一个 recurring automation，rrule：
```
FREQ=WEEKLY;BYDAY=MO,WE,FR;BYHOUR=9;BYMINUTE=0
```
提示词（prompt）示例（可整段给 agent）：
```
读取 config.json；若凭据仍是占位符则停止。
扫描 materials/inbox 递归目录，挑 1 张未处理产品图（排除 created_log/_gen_log/_bilingual_log/media_map 里已有的 img_rel）。
基于该图写 3 个 JSON（覆盖写入单条）：
  draft_articles.json（英文完整版，HTML 含 __IMG__）
  draft_articles_zh.json（中文原生重写，正文 ≤400 中文字，同 img_rel）
  draft_articles_en_word.json（英文精简版，正文 ≤400 英文词，同 img_rel）
依次运行：run_drafts.py（按 default_status 直发/建草稿，已带特色图）→ gen_zh_output.py → build_word.py。
不要重复处理已记录的 img_rel；不要一次生成多篇。最后输出运行报告（处理了哪张图、WP 链接、两个包路径、剩余未处理数）。
```
> 默认 `default_status: publish` 会直接发布；若只想建草稿待审，改成 `"draft"`。

## 移交给别的 agent（可移植交付）

整套 skill 文件夹**直接打包**交给对方即可，零额外配置（除填凭据）：
1. 把本文件夹拷到对方机器（用户级 `~/.workbuddy/skills/` 或项目级 `<项目>/.workbuddy/skills/`）。
2. 对方只需：① 编辑 `config.json` 填本站 WP 凭据；② 跑 `setup.bat`/`setup.sh` 装 python-docx；③ 把产品图丢进 `materials/inbox/`。
3. 无需迁移任何本地图片——`media_map.json` 记录线上媒体 ID，重跑复用线上媒体（首次运行会自动生成空 map）。

> 若想「原样续跑本站（moldmro.com）不重复发图」，请用配套的 `wp-auto-content-pipeline-site-backup`（含真实配置与幂等日志）。通用版不含真实凭据，更安全可分发。
