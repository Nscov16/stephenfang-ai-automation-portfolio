# {{公司名}} · 公司知识库（模板）

> 这是可移植模板。把 `{{...}}` 占位符替换成你公司的真实信息即可。
> 自动成文 agent 每次运行都会读取本文件（文件名为 `company-knowledge.md`，放在 skill 根目录）。
> 英文文章参考「第十一节 英文写作补充包」+「第十二节 关键词矩阵」；中文文章参考中文口径与中文关键词。

## 一、公司基本信息
- 公司名（中）：{{公司中文名}}
- 公司名（英）：{{Company English Name}}
- 品牌名 / 缩写：{{Brand}}
- 一句话定位：{{用一句话说明你是做什么的、服务谁}}
- 成立年份 / 规模：{{选填}}
- 官网：{{https://...}}

## 二、核心业务与产品体系
- 主营产品 1：{{产品名}} — {{一句话说明}}
- 主营产品 2：{{产品名}} — {{一句话说明}}
- 主营产品 3：{{产品名}} — {{一句话说明}}
- （可按需增删；每个产品建议配 1+ 张产品图放入 materials/inbox/）

## 三、品牌调性与写作风格
- 目标读者：{{如「海外采购 / 工程师 / 行业买家」}}
- 语气：{{专业、务实、不夸大}}
- 不要：{{如虚假数据、绝对化用语（最好/第一/唯一）}}
- 要：{{具体参数、可验证事实、读者痛点导向}}

## 四、资质与认证
- {{ISO 9001 / IATF 16949 / 行业认证等，附可核实说明}}

## 五、制造能力（设备清单摘要）
- {{如 CNC 精度、腔数能力、材料范围、热处理能力，用要点列出}}

## 六、合作伙伴与标杆客户
- {{可选：行业客户 / 合作案例，避免编造未授权披露的名单}}

## 七、专业术语表
- 中文术语 → 英文：{{如 瓶坯模具 → preform mould}}
- 中文术语 → 英文：{{如 型芯 → core}}
- 中文术语 → 英文：{{如 型腔 → cavity}}
- （英文文章用英术语；中文文章用中术语；避免中英混排造成歧义）

## 八、雷点与禁忌
- 不要编造公司未提供的夸大事实
- 不要使用绝对化用语（最好 / 第一 / 唯一）
- 数据须可核实，不确定用知识库口径
- {{其它行业-specific 禁忌}}

## 九、SEO 核心关键词（建站/文章可用）
- 英文产品词：{{precision mold components, mold core, mold cavity, ...}}
- 英文行业词：{{packaging mold, medical mold, injection mold manufacturing, ...}}
- 中文词：{{按你行业补充}}

## 十、网站栏目规划（供自动发文分类参考）
- 默认分类 ID：{{WordPress 分类 ID，对应 config.json 的 default_category_id}}
- 分类名：{{如 Blog / News / Products}}

## 十一、英文写作补充包（English Writing Pack）
- 英文简介（供文章首段/ About 风格）：{{2-3 句公司英文简介}}
- 术语（英文）：{{core, cavity, insert, ejection, gate, ...}}
- SEO 关键词（英文，分层）：
  - Layer 1 产品词：{{Precision Mold Components / Mold Core / Mold Cavity / Mold Insert}}
  - Layer 2 行业词：{{Packaging Mold / Medical Mold / Injection Mold Manufacturing / Thin Wall Mold}}
  - Layer 3 知识型问句（兼作 H2 小标题）：{{What is a mold insert? / How to choose mold steel? / Mold core vs cavity?}}
- 雷区（英文）：{{don't overclaim; cite verifiable specs}}
- 标准结尾：{{简短品牌背书段 + 联系信息}}

## 十二、关键词矩阵与 SEO 策略库
### 12.1 英文三层矩阵（标题埋 Layer1，H2 用 Layer3 问句）
- Layer 1 产品词：{{...}}
- Layer 2 行业词：{{...}}
- Layer 3 知识型问句：{{...}}
- 用法说明：SEO 不要只盯单个词，要建矩阵；Layer1 放标题/首段，Layer3 既是关键词也是读者痛点。

### 12.2 中文 SEO 集群（选题/标题参考）
- 问题痛点型：{{...}}
- 方案型：{{...}}
- 产品发现比较型：{{...}}
- 应用场景型：{{...}}
- 学习资源型：{{...}}
- 品牌精确型：{{统一用「{{品牌中文}} / {{Brand}}」}}
- 地域本地化型：{{...}}

---
> 填完后把本文件重命名为 `company-knowledge.md`（或复制内容过去）放在 skill 根目录，agent 即可读取。
