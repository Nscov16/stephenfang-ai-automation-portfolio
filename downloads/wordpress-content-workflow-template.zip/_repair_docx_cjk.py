# -*- coding: utf-8 -*-
"""
_repair_docx_cjk.py — 把 docx 清理为「英文-only + 无残留」的实用工具（可移植）。

适用场景（踩坑后沉淀）：
  1. 双语模板（EN+ZH 同档）想转纯英文 -> 删到首个中文 Heading 1 为止。
  2. 旧版生成器残留三类垃圾，需清理：
     P2 裸文件名段落（如 '\nclean.png\n'、'\nPP可立袋…场景.png\n'，腾讯文档会误渲染成缩略图）
     P3 文末重复的 '[Product image — see separate file: ...]' 引用
     P4 空 '\n' 行段（HTML 解析器残留的 <w:br/>）
  3. 行内中文术语注解（如 "The pipette tip core (吸液头型芯) forms"）一并清掉。

关键修复：CJK 清理必须对「整段文字」合并处理再回写为单个 run，
  否则跨 run 边界的空格会丢失（出现 "Thepipette tip coreforms" 破词）。

用法（BASE 自动推导）：
  python _repair_docx_cjk.py [目录]      # 默认扫描 BASE/output/bilingual
幂等：重跑无副作用（已干净的段落不会再变）。建议先备份再跑。
"""
import os, re, sys
from docx import Document
from docx.oxml.ns import qn

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = HERE

TARGET = sys.argv[1] if len(sys.argv) > 1 else os.path.join(BASE, "output", "bilingual")

CJK = re.compile(r'[\u4e00-\u9fff\uff00-\uffef\u3000-\u303f\uff5e\uffe5]')
PARENS = re.compile(r'\([^()]*[一-鿿][^()]*\)')
BRACKETS = re.compile(r'[\[【][^\]】]*[一-鿿][^\]】]*[\]】]')


def has_cjk(s):
    return any('\u4e00' <= c <= '\u9fff' for c in s)


def strip_cjk(t):
    """Strip Chinese parens & CJK chars, preserving spaces around removed spans."""
    if not t:
        return t
    orig = t

    def paren_repl(m):
        inner = m.group(0)[1:-1].strip()
        return ' ' if has_cjk(inner) else m.group(0)
    t = re.sub(r'\([^()]*\)', paren_repl, t)
    t = re.sub(r'[\[【][^\]】]*[\]】]', paren_repl, t)
    t = CJK.sub(' ', t)
    t = re.sub(r' {2,}', ' ', t)
    t = re.sub(r' +([,.;:!?\)])', r'\1', t)
    t = t.strip()
    return t if t != orig else orig


def is_filename_only_text(text):
    cleaned = text.replace('\n', '').strip()
    return bool(re.match(r'^[A-Za-z0-9_\-\u4e00-\u9fff（）()\\.（）]+\.(png|jpg|jpeg|webp|gif)$',
                         cleaned, re.IGNORECASE))


def is_product_image_ref(text):
    return '[Product image — see separate file:' in text


def is_empty_linebreak_para(para):
    txt = para.text
    if txt.strip():
        return False
    for r in para.runs:
        for elem in r.element.iter(qn('w:t')):
            if (elem.text or '').strip():
                return False
    return True


def find_zh_boundary(doc):
    for i, p in enumerate(doc.paragraphs):
        if (p.style and p.style.name == 'Heading 1') and has_cjk(p.text):
            return i
    return None


def drop_paragraph(para):
    p = para._p
    p.getparent().remove(p)


def clean_paragraph_text(para):
    full_text = para.text
    if not full_text:
        return False
    if not has_cjk(full_text):
        return False
    cleaned = strip_cjk(full_text)
    if cleaned == full_text:
        return False
    p_el = para._p
    for r in list(p_el.findall(qn('w:r'))):
        p_el.remove(r)
    para.add_run(cleaned)
    return True


def repair_one(path):
    doc = Document(path)
    paras = list(doc.paragraphs)

    # P1: drop ZH section (first Chinese Heading 1 onward)
    boundary = find_zh_boundary(doc)
    if boundary is not None:
        for p in paras[boundary:]:
            drop_paragraph(p)

    seen_img_ref = False
    dropped_files = dropped_dup = dropped_empty = stripped_cjk = 0

    for p in list(doc.paragraphs):
        text = p.text
        if text.strip() and is_filename_only_text(text):
            drop_paragraph(p); dropped_files += 1; continue
        if is_product_image_ref(text):
            if seen_img_ref:
                drop_paragraph(p); dropped_dup += 1; continue
            seen_img_ref = True
        if is_empty_linebreak_para(p):
            drop_paragraph(p); dropped_empty += 1; continue
        if clean_paragraph_text(p):
            stripped_cjk += 1

    # 末尾若仍是重复 product-image 引用，删掉
    final = list(doc.paragraphs)
    if len(final) > 2 and is_product_image_ref(final[-1].text):
        drop_paragraph(final[-1]); dropped_dup += 1

    doc.save(path)
    return {'boundary': boundary, 'dropped_files': dropped_files,
            'dropped_dup': dropped_dup, 'dropped_empty': dropped_empty,
            'stripped_cjk': stripped_cjk}


def main():
    files = sorted(f for f in os.listdir(TARGET) if f.endswith('.docx')) if os.path.isdir(TARGET) else []
    if not files:
        print(f"未找到 docx：{TARGET}")
        return
    print(f"=== Repairing {len(files)} docx in {TARGET} ===\n")
    ok_all = True
    for fn in files:
        p = os.path.join(TARGET, fn)
        s = repair_one(p)
        n_zh = sum(1 for x in Document(p).paragraphs if has_cjk(x.text))
        n_imgref = sum(1 for x in Document(p).paragraphs if is_product_image_ref(x.text))
        n_filename = sum(1 for x in Document(p).paragraphs if is_filename_only_text(x.text))
        flag = "OK" if (n_zh == 0 and n_imgref <= 1 and n_filename == 0) else "FAIL"
        if flag == "FAIL":
            ok_all = False
        print(f"  [{flag}] {fn[:55]:55s} boundary={s['boundary']} "
              f"files={s['dropped_files']} dup={s['dropped_dup']} empty={s['dropped_empty']} cjk={s['stripped_cjk']}")
    print(f"\n=== {'ALL CLEAN' if ok_all else 'CHECK FAILURES ABOVE'} ===")


if __name__ == "__main__":
    main()
