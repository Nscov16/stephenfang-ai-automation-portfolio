#!/usr/bin/env bash
# 一键安装：建 venv 并安装依赖（python-docx）
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "未找到 python3，请先安装 Python 3.10+" >&2
  exit 1
fi
if [ ! -d venv ]; then
  echo "创建虚拟环境 venv ..."
  python3 -m venv venv
fi
# shellcheck disable=SC1091
source venv/bin/activate
echo "安装依赖 python-docx ..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo
echo "安装完成。请编辑 config.json 填入你的 WordPress 站点信息。"
echo "运行示例："
echo "  venv/bin/python draft_run/run_drafts.py"
echo "  venv/bin/python draft_run/gen_zh_output.py"
echo "  venv/bin/python draft_run/build_word.py"
