# -*- coding: utf-8 -*-
"""
run_drafts.py — 英文文章发布到 WordPress（自动上传图、设为特色图片）。

用法：python run_drafts.py
读：BASE/config.json、BASE/draft_articles.json（含 img_rel/title/html，__IMG__ 占位）
写：WordPress posts（按 config.wordpress.default_status 直发或建草稿）
     BASE/draft_run/media_map.json（img_rel -> media_id，防同名撞车核心）
     BASE/draft_run/created_log.json（已发幂等日志）
     BASE/materials/processed/（归档已处理图片）
幂等：同一 img_rel 已成功发文且帖子仍存在 -> 跳过。
BASE 从本文件所在路径自动推导，整包可移植到任意机器/agent。
"""
import base64, json, os, shutil, urllib.request, urllib.error

# ── 配置（BASE 从脚本自身路径推导，保证可移植）──────────────
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)  # <skill root> == 项目根
with open(os.path.join(BASE, "config.json"), "r", encoding="utf-8") as f:
    cfg = json.load(f)

SITE   = cfg["wordpress"]["site_url"].rstrip("/")
USER   = cfg["wordpress"]["username"]
APP_PW = cfg["wordpress"]["application_password"]
UA     = cfg["wordpress"].get("user_agent", "Mozilla/5.0")
CAT_ID = int(cfg["wordpress"].get("default_category_id", 1))
INBOX      = os.path.join(BASE, cfg["materials"]["inbox"])
PROCESSED  = os.path.join(BASE, cfg["materials"]["processed"])

AUTH = base64.b64encode(f"{USER}:{APP_PW}".encode()).decode()

# ── 文章数据 ────────────────────────────────────────────────
ARTICLES_JSON = os.path.join(BASE, "draft_articles.json")
with open(ARTICLES_JSON, "r", encoding="utf-8") as f:
    articles = json.load(f)

# ── HTTP 工具函数 ───────────────────────────────────────────
def api_post(path, data=None, content_type=None, body_bytes=None):
    headers = {"Authorization": f"Basic {AUTH}", "User-Agent": UA}
    if body_bytes is not None:
        if content_type:
            headers["Content-Type"] = content_type
    else:
        # JSON 路径：未显式指定时默认 application/json，否则 urllib 会误用
        # x-www-form-urlencoded，导致 WP 解析不到 title/content（empty_content 错误）
        headers["Content-Type"] = content_type or "application/json; charset=utf-8"
    body = body_bytes if body_bytes is not None else (
        json.dumps(data, ensure_ascii=False).encode("utf-8") if data else None)
    req = urllib.request.Request(SITE + path, headers=headers, data=body, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=60)
        return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:300]
        print(f"  [HTTP {e.code}] {path} => {err}")
        raise

def api_get(path):
    req = urllib.request.Request(SITE + path,
                                 headers={"Authorization": f"Basic {AUTH}", "User-Agent": UA})
    try:
        resp = urllib.request.urlopen(req, timeout=60)
        return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:300]
        print(f"  [HTTP {e.code}] {path} => {err}")
        raise

# media_map.json：img_rel -> 已上传的 media_id，存在时复用、避免重复上传
MEDIA_MAP_PATH = os.path.join(BASE, "draft_run", "media_map.json")
media_map = {}
if os.path.exists(MEDIA_MAP_PATH):
    media_map = json.load(open(MEDIA_MAP_PATH, "r", encoding="utf-8"))
    print(f"已加载 media_map（{len(media_map)} 条），将复用已上传媒体，不重复上传")

# created_log.json：img_rel -> {post_id, edit_link}，已成功发文则跳过，避免重复
CREATED_LOG_PATH = os.path.join(BASE, "draft_run", "created_log.json")
created_log = {}
if os.path.exists(CREATED_LOG_PATH):
    created_log = json.load(open(CREATED_LOG_PATH, "r", encoding="utf-8"))

def upload_media(img_abs_path):
    """上传图片到 WordPress 媒体库，返回 (source_url, media_id)"""
    fname = os.path.basename(img_abs_path)
    fsize = os.path.getsize(img_abs_path)
    print(f"  上传图片: {fname} ({fsize/1024:.0f}KB) ...", end=" ", flush=True)

    with open(img_abs_path, "rb") as f:
        img_data = f.read()

    boundary = "----FormBoundary7MA4YWxkTrZu0gW"
    body_parts = []
    body_parts.append(f'--{boundary}\r\n'.encode())
    body_parts.append(
        f'Content-Disposition: form-data; name="file"; filename="{fname}"\r\n'
        f'Content-Type: image/png\r\n\r\n'.encode()
    )
    body_parts.append(img_data)
    body_parts.append(f'\r\n--{boundary}--\r\n'.encode())
    body = b"".join(body_parts)

    media = api_post("/wp-json/wp/v2/media",
                     content_type=f"multipart/form-data; boundary={boundary}",
                     body_bytes=body)
    url = media.get("source_url", "")
    mid = media.get("id", "")
    print(f"OK id={mid}")
    return url, mid

def create_post(title, html_content, featured_media=None):
    """创建文章，返回 (edit_link, post_id)。featured_media 设为特色图片。"""
    status = cfg["wordpress"].get("default_status", "draft")
    payload = {
        "title": title,
        "content": html_content,
        "status": status,
        "categories": [CAT_ID]
    }
    if featured_media:
        payload["featured_media"] = featured_media
    post = api_post("/wp-json/wp/v2/posts", data=payload)
    link = post.get("link", "")
    pid = post.get("id", "")
    return link, pid

# ── 主流程 ──────────────────────────────────────────────────
os.makedirs(PROCESSED, exist_ok=True)

results = []

for i, art in enumerate(articles):
    img_rel   = art["img_rel"]
    title     = art["title"]
    html_body = art["html"]

    img_abs = os.path.join(INBOX, img_rel.replace("/", os.sep))

    # 幂等：同一 img_rel 已成功建过帖子且帖子仍在，则跳过，避免重复发文
    if art.get("img_rel") in created_log:
        _pid = created_log[art["img_rel"]].get("post_id")
        try:
            api_get(f"/wp-json/wp/v2/posts/{_pid}")
            print(f"\n[文章 {i+1}] 已存在帖子 id={_pid}，跳过（避免重复发文）")
            results.append({"index": i + 1, "title": title, "post_id": _pid,
                            "edit_link": created_log[art["img_rel"]].get("edit_link", ""),
                            "status": "skipped"})
            continue
        except Exception:
            pass  # 帖子已删除，继续重建

    if not os.path.exists(img_abs):
        # 复用模式（media_map 命中）：本地原图已归档，跳过存在性检查
        if art.get("img_rel") in media_map:
            print(f"\n[文章 {i+1}] 复用 media_map 媒体（本地原图已归档），继续")
        else:
            print(f"\n[文章 {i+1}] 图片不存在: {img_abs}, 跳过")
            continue

    print(f"\n{'='*60}")
    print(f"[文章 {i+1}/{len(articles)}] {title}")
    print(f"{'='*60}")

    try:
        # Step 1: 上传图片（或复用 media_map 中已上传的媒体）
        if art.get("img_rel") in media_map:
            mid = media_map[art["img_rel"]]
            print(f"  复用已上传媒体 id={mid} ...", end=" ", flush=True)
            img_url = api_get(f"/wp-json/wp/v2/media/{mid}").get("source_url", "")
            img_id = mid
            print("OK" if img_url else "FAIL(无 source_url)")
        else:
            img_url, img_id = upload_media(img_abs)

        # 记录 img_rel -> media_id，供 gen_zh_output/build_word 精确取图（避免本地同名撞车）
        media_map[art["img_rel"]] = img_id

        # Step 2: 替换图片占位符
        final_html = html_body.replace("__IMG__",
            f'<figure style="text-align:center;margin:20px 0;">'
            f'<img src="{img_url}" alt="{os.path.basename(img_abs)}" '
            f'style="max-width:100%;height:auto;border-radius:8px;" />'
            f'<figcaption style="font-size:12px;color:#888;margin-top:4px;">'
            f'{os.path.basename(img_abs)}</figcaption></figure>')

        # Step 3: 创建文章（并设为特色图片）
        edit_link, post_id = create_post(title, final_html, featured_media=img_id)
        print(f"  文章已创建: {edit_link}  (特色图片 media_id={img_id})")

        # Step 4: 归档图片（仅当本地原图仍存在时；复用模式已归档则跳过）
        if os.path.exists(img_abs):
            dest = os.path.join(PROCESSED, os.path.basename(img_abs))
            # 避免同名覆盖
            if os.path.exists(dest):
                base, ext = os.path.splitext(dest)
                dest = f"{base}_{i+1}{ext}"
            shutil.move(img_abs, dest)
            print(f"  已归档至: {dest}")
        else:
            print(f"  本地原图已归档/不存在，跳过移动")

        results.append({
            "index": i + 1,
            "title": title,
            "post_id": post_id,
            "edit_link": edit_link,
            "media_id": img_id,
            "status": "success"
        })

        # 记录已创建（幂等）
        created_log[art["img_rel"]] = {"post_id": post_id, "edit_link": edit_link}

    except Exception as e:
        print(f"  处理失败: {e}")
        results.append({
            "index": i + 1,
            "title": title,
            "error": str(e),
            "status": "failed"
        })

# ── 输出汇总报告 ───────────────────────────────────────────
print(f"\n{'='*60}")
print("运行报告")
print(f"{'='*60}")
ok = sum(1 for r in results if r["status"] == "success")
skip = sum(1 for r in results if r["status"] == "skipped")
fail = len(results) - ok - skip
print(f"总计: {len(results)} 篇 | 成功: {ok} | 跳过(已存在): {skip} | 失败: {fail}")
for r in results:
    if r["status"] == "success":
        print(f"  OK [{r['index']}] {r['title'][:40]}... -> {r['edit_link']}")
    elif r["status"] == "skipped":
        print(f"  跳过 [{r['index']}] {r['title'][:40]}... -> {r.get('edit_link','')}")
    else:
        print(f"  FAIL [{r['index']}] {r['title'][:40]}... -> {r.get('error','?')[:80]}")

# 保存幂等记录（供下次运行跳过已发文）
with open(CREATED_LOG_PATH, "w", encoding="utf-8") as f:
    json.dump(created_log, f, ensure_ascii=False, indent=2)

# 保存 media_map（img_rel -> media_id），保证后续 Word/中企动力取图精确对应
with open(MEDIA_MAP_PATH, "w", encoding="utf-8") as f:
    json.dump(media_map, f, ensure_ascii=False, indent=2)

# 保存结果 JSON
report_path = os.path.join(BASE, "draft_run", "run_report.json")
with open(report_path, "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print(f"\n详细报告已保存: {report_path}")
