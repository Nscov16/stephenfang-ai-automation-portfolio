# -*- coding: utf-8 -*-
"""
build_word.py — 生成「英文版（不含图）Word + 独立图片」存档，按日期归类。

格式（一篇一档、英文-only、不含图）：
  - 每篇文章单独生成一个 Word 文件（一篇文章 = 一个 .docx），不再合并到同一个日期文档。
  - Word 仅含英文标题 + 英文正文，不内嵌图片；
    原 __IMG__ 图位改为一行图片引用说明（指向同目录独立图片文件）。
  - 图片单独拎出，作为独立文件放在同一日期目录下：<slug>.<图片扩展名>。

产出：output/bilingual/YYYY-MM-DD/<slug>.docx
      output/bilingual/YYYY-MM-DD/<slug>.<ext>（独立产品图）
幂等：output/bilingual/_bilingual_log.json 记录已收录的 img_rel，重跑不重复。
BASE 从本文件所在路径自动推导，整包可移植。
"""
import base64
import datetime
import json
import os
import re
import urllib.parse
import urllib.request
from html.parser import HTMLParser

from docx import Document
from docx.shared import Pt

# ── BASE 自动推导 ───────────────────────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)
with open(os.path.join(BASE, "config.json"), "r", encoding="utf-8") as f:
    cfg = json.load(f)

SITE = cfg["wordpress"]["site_url"].rstrip("/")
USER = cfg["wordpress"]["username"]
APP_PW = cfg["wordpress"]["application_password"]
UA = cfg["wordpress"].get("user_agent", "Mozilla/5.0")
AUTH = base64.b64encode(f"{USER}:{APP_PW}".encode()).decode()

EN_JSON = os.path.join(BASE, "draft_articles_en_word.json")
EN_JSON_FULL = os.path.join(BASE, "draft_articles.json")  # 回退用（完整版）
MEDIA_MAP = json.load(open(os.path.join(BASE, "draft_run", "media_map.json"), "r", encoding="utf-8"))
PROCESSED_DIR = os.path.join(BASE, "materials", "processed")  # 本地图片回退目录
OUT_ROOT = os.path.join(BASE, "output", "bilingual")
LOG_PATH = os.path.join(OUT_ROOT, "_bilingual_log.json")

RUN_DATE = datetime.date.today().strftime("%Y-%m-%d")
RUN_DIR = os.path.join(OUT_ROOT, RUN_DATE)
os.makedirs(RUN_DIR, exist_ok=True)

if os.path.exists(EN_JSON):
    en_articles = json.load(open(EN_JSON, "r", encoding="utf-8"))
else:
    print(f"[warn] 未找到 {os.path.basename(EN_JSON)}，回退到 draft_articles.json（完整版将按 400 词硬上限截断）")
    en_articles = json.load(open(EN_JSON_FULL, "r", encoding="utf-8"))


def api_get(path):
    req = urllib.request.Request(SITE + path,
                                 headers={"Authorization": f"Basic {AUTH}", "User-Agent": UA})
    return json.loads(urllib.request.urlopen(req, timeout=60).read().decode())


def get_image_bytes(img_rel):
    """优先从 WP 媒体库下载（带 User-Agent + 中文 URL 编码），失败回退本地 processed。返回 (bytes, ext) 或 (None, None)。"""
    mid = MEDIA_MAP.get(img_rel)
    if mid:
        try:
            m = api_get(f"/wp-json/wp/v2/media/{mid}")
            url = m.get("source_url", "")
            url = urllib.parse.quote(url, safe='/:?=&%')  # 中文文件名编码，规避 ascii 错误
            data = urllib.request.urlopen(
                urllib.request.Request(url, headers={"User-Agent": UA}), timeout=60).read()
            ext = os.path.splitext(url.split("?")[0])[1].lstrip(".") or "png"
            return data, ext
        except Exception as e:
            print(f"  [warn] 媒体库下载失败 media={mid} => {e}")
    # 回退：本地 processed（按 basename 或完整 img_rel）
    for cand in (os.path.join(PROCESSED_DIR, os.path.basename(img_rel)),
                 os.path.join(PROCESSED_DIR, img_rel.replace("/", os.sep))):
        if os.path.exists(cand):
            try:
                with open(cand, "rb") as fh:
                    return fh.read(), os.path.splitext(cand)[1].lstrip(".") or "png"
            except Exception as e:
                print(f"  [warn] 本地图片读取失败 {cand} => {e}")
    return None, None


def set_cjk_font(doc, font="Microsoft YaHei"):
    style = doc.styles["Normal"]
    style.font.name = font
    style.font.size = Pt(11)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(__import__("docx").oxml.ns.qn("w:eastAsia"), font)


def sanitize(name):
    s = re.sub(r'[\\/:*?"<>|]', "", name).strip()
    return s[:60] if s else "article"


class HTMLToDocx(HTMLParser):
    """英文 HTML -> Word（不嵌图）。__IMG__ 图位改为图片引用说明。
    硬上限：正文英文词数不超过 MAX_WORDS（默认 400），超出部分截断。"""
    MAX_WORDS = 400

    def __init__(self, doc, img_note):
        super().__init__(convert_charrefs=True)
        self.doc = doc
        self.img_note = img_note  # 图片引用说明文本
        self.bold = False
        self.current = None
        self.in_table = False
        self.in_cell = False
        self.table_rows = []
        self.cur_row = []
        self.cell_buffer = []
        self.words = 0
        self.truncated = False

    def _add_text(self, text):
        if not text:
            return
        if self.words >= self.MAX_WORDS:
            self.truncated = True
            return
        parts = text.split()
        n = len(parts)
        avail = self.MAX_WORDS - self.words
        if n > avail:
            text = " ".join(parts[:avail])
            self.truncated = True
            n = avail
        if self.in_cell:
            self.cell_buffer.append(text)
            self.words += n
            return
        if self.current is None:
            self.current = self.doc.add_paragraph()
        run = self.current.add_run(text)
        run.bold = self.bold
        self.words += n

    def _add_image_note(self):
        p = self.doc.add_paragraph()
        r = p.add_run(self.img_note)
        r.italic = True
        r.font.size = Pt(9)

    def handle_starttag(self, tag, attrs):
        if tag in ("h2", "h3"):
            self.current = self.doc.add_heading(level=2 if tag == "h2" else 3)
        elif tag == "p":
            self.current = self.doc.add_paragraph()
        elif tag == "li":
            self.current = self.doc.add_paragraph(style="List Bullet")
        elif tag in ("br",):
            if self.current and not self.in_cell:
                self.current.add_run().add_break()
        elif tag == "strong":
            self.bold = True
        elif tag == "table":
            self.in_table = True
            self.table_rows = []
        elif tag == "tr":
            self.cur_row = []
        elif tag in ("td", "th"):
            self.in_cell = True
            self.cell_buffer = []
        # img / imginsert / __IMG__ 一律不嵌图，由 _add_image_note 处理

    def handle_endtag(self, tag):
        if tag in ("h2", "h3", "p"):
            self.current = None
        elif tag == "strong":
            self.bold = False
        elif tag in ("td", "th"):
            self.in_cell = False
            self.cur_row.append("".join(self.cell_buffer))
            self.cell_buffer = []
        elif tag == "tr":
            self.table_rows.append(self.cur_row)
        elif tag == "table":
            self._flush_table()
            self.in_table = False

    def handle_data(self, data):
        if self.in_table and not self.in_cell:
            return
        if "__IMG__" in data:
            parts = data.split("__IMG__")
            for i, part in enumerate(parts):
                if part:
                    self._add_text(part)
                if i < len(parts) - 1:
                    self._add_image_note()
        else:
            self._add_text(data)

    def _flush_table(self):
        if not self.table_rows:
            return
        ncols = max((len(r) for r in self.table_rows), default=0)
        t = self.doc.add_table(rows=len(self.table_rows), cols=ncols)
        try:
            t.style = "Table Grid"
        except Exception:
            pass
        for i, row in enumerate(self.table_rows):
            cells = t.rows[i].cells
            for j in range(ncols):
                cells[j].text = row[j] if j < len(row) else ""


# ── 主流程（每篇文章一个独立 Word 文件）──────────────────────
log = {}
if os.path.exists(LOG_PATH):
    try:
        log = json.load(open(LOG_PATH, "r", encoding="utf-8"))
    except Exception:
        log = {}

added = 0
skipped = 0
for art in en_articles:
    img_rel = art["img_rel"]
    en_title = art["title"].strip()

    # 幂等：已在日志 -> 跳过
    if img_rel in log:
        print(f"[跳过] 已收录：{img_rel}")
        skipped += 1
        continue

    # 计算每篇独立文件名（slug），避免与同目录其它文章撞名
    base_slug = sanitize(en_title)
    slug = base_slug
    n = 1
    while True:
        per_docx = os.path.join(RUN_DIR, f"{slug}.docx")
        if not os.path.exists(per_docx):
            break
        slug = f"{base_slug}_{n}"
        n += 1

    # 1) 英文正文 Word（不含图，每篇独立）
    img_bytes, img_ext = get_image_bytes(img_rel)
    img_filename = f"{slug}.{img_ext}" if img_ext else None
    img_note = f"[Product image — see separate file: {img_filename}]" if img_filename else "[Product image unavailable]"

    doc = Document()
    set_cjk_font(doc)
    doc.add_heading(en_title, level=1)
    parser = HTMLToDocx(doc, img_note)
    parser.feed(art["html"])
    if parser.truncated:
        print(f"  [warn] 英文正文超过 {parser.MAX_WORDS} 词，已截断至上限")

    # 2) 独立图片文件（按日期归类，与 docx 同目录）
    if img_bytes and img_filename:
        img_dst = os.path.join(RUN_DIR, img_filename)
        with open(img_dst, "wb") as wf:
            wf.write(img_bytes)
        print(f"[收录] {img_rel} -> EN 单篇文档：{os.path.basename(per_docx)}（图：{img_filename}）")
    else:
        print(f"[收录] {img_rel} -> EN 单篇文档：{os.path.basename(per_docx)}（无图）")

    doc.save(per_docx)
    log[img_rel] = {"date": RUN_DATE, "file": os.path.relpath(per_docx, BASE),
                    "image": img_filename}
    added += 1

json.dump(log, open(LOG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"\n完成：本运行新增 {added} 篇（跳过 {skipped}）。每篇独立 Word 位于：{RUN_DIR}")
