# -*- coding: utf-8 -*-
"""
fix_featured_drafts.py — 为缺少特色图的英文草稿补设 featured_media。
- 只修改 featured_media 字段，不改 status（保持草稿，不发布）。
- 默认 DRY_RUN=True：仅打印将要执行的映射，不写 WP。
- 设 DRY_RUN=False 才真正写入（用法：python fix_featured_drafts.py --apply）。
图片 media_id 通过帖子正文 <img src> 反查 WP 媒体库（slug 精确匹配，失败再全库扫描 basename）。
"""
import base64
import json
import os
import re
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))   # .../draft_run
BASE = os.path.dirname(HERE)                          # skill 根目录
cfg = json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))

SITE = cfg["wordpress"]["site_url"].rstrip("/")
USER = cfg["wordpress"]["username"]
APP_PW = cfg["wordpress"]["application_password"]
UA = cfg["wordpress"].get("user_agent", "Mozilla/5.0")
AUTH = base64.b64encode(f"{USER}:{APP_PW}".encode()).decode()

DRY_RUN = "--apply" not in sys.argv


def api_req(method, path, data=None):
    headers = {"Authorization": f"Basic {AUTH}", "User-Agent": UA}
    body = None
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
        body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(SITE + path, data=body, headers=headers, method=method)
    return json.loads(urllib.request.urlopen(req, timeout=60).read().decode())


def slug_from_src(src):
    fn = src.split("?")[0].rsplit("/", 1)[-1]
    fn = re.sub(r"-\d+x\d+(?=\.[a-zA-Z]+$)", "", fn)  # strip resize -WxH
    return fn.rsplit(".", 1)[0].lower()


# media cache (id -> basename of source_url), built lazily by full scan if needed
_media_by_basename = {}


def build_media_cache():
    page = 1
    while True:
        chunk = api_req("GET", f"/wp-json/wp/v2/media?per_page=100&page={page}")
        if not chunk:
            break
        for m in chunk:
            su = m.get("source_url", "")
            bn = su.split("?")[0].rsplit("/", 1)[-1].lower()
            _media_by_basename[bn] = m["id"]
        if len(chunk) < 100:
            break
        page += 1


def resolve_media_id(slug, src):
    # 1) slug exact
    try:
        m = api_req("GET", "/wp-json/wp/v2/media?slug=" + urllib.parse.quote(slug) + "&per_page=5")
        if m:
            return m[0]["id"], "slug", _bn(m[0].get("source_url", ""))
    except Exception:
        pass
    # 2) full-scan basename match
    if not _media_by_basename:
        build_media_cache()
    bn = src.split("?")[0].rsplit("/", 1)[-1].lower()
    if bn in _media_by_basename:
        mid = _media_by_basename[bn]
        # fetch to get source_url basename for verification
        try:
            mm = api_req("GET", f"/wp-json/wp/v2/media/{mid}")
            return mid, "scan", _bn(mm.get("source_url", ""))
        except Exception:
            return mid, "scan", ""
    return None, "none", ""


def _bn(url):
    return url.split("?")[0].rsplit("/", 1)[-1].lower()


def _matches(src, media_bn):
    """比较帖子图片与媒体源文件名是否同一张（忽略 -scaled / -WxH 后缀）。"""
    a = re.sub(r"-scaled(?=\.[a-z]+$)?", "", src.split("?")[0].rsplit("/", 1)[-1].lower())
    a = re.sub(r"-\d+x\d+(?=\.[a-z]+$)?", "", a).rsplit(".", 1)[0]
    b = re.sub(r"-scaled(?=\.[a-z]+$)?", "", media_bn).rsplit(".", 1)[0]
    return a == b


def main():
    drafts = []
    page = 1
    while True:
        chunk = api_req("GET", f"/wp-json/wp/v2/posts?status=draft&per_page=100&page={page}")
        if not chunk:
            break
        drafts += chunk
        if len(chunk) < 100:
            break
        page += 1

    print(f"DRY_RUN={DRY_RUN}  草稿总数={len(drafts)}\n")
    plan = []
    for p in drafts:
        pid = p["id"]
        if p.get("featured_media", 0):
            print(f"[已有] #{pid} 特色图={p['featured_media']} 跳过")
            continue
        html = p.get("content", {}).get("rendered", "")
        imgs = re.findall(r'<img[^>]+src="([^"]+)"', html)
        if not imgs:
            print(f"[无图] #{pid} {p.get('title',{}).get('rendered','')[:20]} 跳过")
            continue
        src = imgs[0]
        slug = slug_from_src(src)
        mid, how, mbn = resolve_media_id(slug, src)
        if not mid:
            print(f"[FAIL] #{pid} 无法解析 slug={slug} src={src[:60]}")
            continue
        if not _matches(src, mbn):
            print(f"[FAIL] #{pid} 文件名不匹配：帖子={src.rsplit('/',1)[-1]} 媒体={mbn}")
            continue
        plan.append((pid, mid))
        print(f"[{'将设' if DRY_RUN else '已设'}] #{pid} -> media {mid} (via {how})  slug={slug}  校验✓")

    if DRY_RUN or not plan:
        print("\n（dry-run 结束，未写入。加 --apply 参数执行写入。）")
        return

    print("\n=== 开始写入 ===")
    for pid, mid in plan:
        api_req("POST", f"/wp-json/wp/v2/posts/{pid}", {"featured_media": mid})
        # 重新拉取确认
        after = api_req("GET", f"/wp-json/wp/v2/posts/{pid}?context=edit")
        print(f"#{pid}: featured_media={after.get('featured_media')} status={after.get('status')}")


if __name__ == "__main__":
    main()
