# -*- coding: utf-8 -*-
"""
gen_zh_output.py — 为中文站（中企动力会员控制平台，用户手动发）生成发布包。
中企动力无公开自动发文 API，故生成用户手动粘贴/上传的内容包。

用法：python gen_zh_output.py
产出（按日期分类）：
  output/zhongqi/YYYY-MM-DD/<中文标题>.docx   （纯文字，不嵌图）
  output/zhongqi/YYYY-MM-DD/<中文标题>.<图片扩展名>  （配套图片文件，独立存在）
说明：
  - Word 内不含图片（用户要求图片不放进 word），图片作为独立文件附在同目录。
  - 不再生成 HTML / Markdown（用户只要 Word 形态）。
  - 正文中文硬上限 MAX_CHARS（默认 400），超出截断。
幂等：output/zhongqi/_gen_log.json 记录已生成的 img_rel，重跑不重复。
BASE 从本文件所在路径自动推导，整包可移植。
"""
import base64
import datetime
import glob
import json
import os
import re
import shutil
import urllib.parse
import urllib.request
from html.parser import HTMLParser

from docx import Document
from docx.shared import Pt

# ── BASE 自动推导 ───────────────────────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)
with open(os.path.join(BASE, "config.json"), "r", encoding="utf-8") as f:
    cfg = json.load(f)

ZH_JSON = os.path.join(BASE, "draft_articles_zh.json")
MEDIA_MAP = json.load(open(os.path.join(BASE, "draft_run", "media_map.json"), "r", encoding="utf-8"))

# ── WordPress 媒体库凭据（用于按 media_id 精确下载图片，规避本地同名撞车）──
SITE = cfg["wordpress"]["site_url"].rstrip("/")
USER = cfg["wordpress"]["username"]
APP_PW = cfg["wordpress"]["application_password"]
UA = cfg["wordpress"].get("user_agent", "Mozilla/5.0")
AUTH = base64.b64encode(f"{USER}:{APP_PW}".encode()).decode()


def api_get(path):
    req = urllib.request.Request(SITE + path,
                                 headers={"Authorization": f"Basic {AUTH}", "User-Agent": UA})
    return json.loads(urllib.request.urlopen(req, timeout=60).read().decode())


def get_image_b64(media_id):
    """从 WP 媒体库下载图片，返回 (base64_str, ext) 或 (None, None)。"""
    if not media_id:
        return None, None
    try:
        m = api_get(f"/wp-json/wp/v2/media/{media_id}")
        url = m.get("source_url", "")
        # 对中文文件名进行 URL 编码，避免 urllib 报 ascii codec 错误
        url = urllib.parse.quote(url, safe='/:?=&%')
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        data = urllib.request.urlopen(req, timeout=60).read()
        ext = os.path.splitext(url.split("?")[0])[1].lstrip(".") or "png"
        return base64.b64encode(data).decode(), ext
    except Exception as e:
        print(f"  [warn] 图片下载失败 media={media_id} => {e}")
        return None, None

INBOX = os.path.join(BASE, cfg["materials"]["inbox"])
PROCESSED = os.path.join(BASE, cfg["materials"]["processed"])
OUT_ROOT = os.path.join(BASE, "output", "zhongqi")
LOG_PATH = os.path.join(OUT_ROOT, "_gen_log.json")

RUN_DATE = datetime.date.today().strftime("%Y-%m-%d")
RUN_DIR = os.path.join(OUT_ROOT, RUN_DATE)
os.makedirs(RUN_DIR, exist_ok=True)

log = {}
if os.path.exists(LOG_PATH):
    log = json.load(open(LOG_PATH, "r", encoding="utf-8"))

zh_articles = json.load(open(ZH_JSON, "r", encoding="utf-8"))


def find_image(img_rel):
    """定位图片实际文件：先 inbox 原始路径，再 processed 递归按文件名找。"""
    cand = [
        os.path.join(INBOX, img_rel.replace("/", os.sep)),
        os.path.join(PROCESSED, os.path.basename(img_rel)),
    ]
    for c in cand:
        if os.path.exists(c):
            return c
    base = os.path.basename(img_rel)
    hits = glob.glob(os.path.join(PROCESSED, "**", base), recursive=True)
    if hits:
        return hits[0]
    hits = glob.glob(os.path.join(INBOX, "**", base), recursive=True)
    if hits:
        return hits[0]
    return None


def sanitize(name):
    s = re.sub(r'[\\/:*?"<>|]', "", name).strip()
    return s[:40] if s else "article"


class TextHTMLToDocx(HTMLParser):
    """纯文字 HTML→Word 转换（忽略图片，不嵌图）。
    硬上限：正文中文字数不超过 MAX_CHARS（默认 400），超出部分截断。"""
    MAX_CHARS = 400

    def __init__(self, doc):
        super().__init__(convert_charrefs=True)
        self.doc = doc
        self.bold = False
        self.current = None
        self.in_table = False
        self.in_cell = False
        self.table_rows = []
        self.cur_row = []
        self.cell_buffer = []
        self.chars = 0
        self.truncated = False

    def _add_text(self, text):
        if not text:
            return
        if self.chars >= self.MAX_CHARS:
            self.truncated = True
            return
        avail = self.MAX_CHARS - self.chars
        if len(text) > avail:
            text = text[:avail]
            self.truncated = True
        if self.in_cell:
            self.cell_buffer.append(text)
            self.chars += len(text)
            return
        if self.current is None:
            self.current = self.doc.add_paragraph()
        run = self.current.add_run(text)
        run.bold = self.bold
        self.chars += len(text)

    def handle_starttag(self, tag, attrs):
        if tag in ("h2", "h3"):
            self.current = self.doc.add_heading(level=2 if tag == "h2" else 3)
        elif tag == "p":
            self.current = self.doc.add_paragraph()
        elif tag == "li":
            self.current = self.doc.add_paragraph(style="List Bullet")
        elif tag in ("br",):
            if self.current and not self.in_cell:
                self.current.add_run().add_break()
        elif tag == "strong":
            self.bold = True
        elif tag == "table":
            self.in_table = True
            self.table_rows = []
        elif tag == "tr":
            self.cur_row = []
        elif tag in ("td", "th"):
            self.in_cell = True
            self.cell_buffer = []
        # img / imginsert / __IMG__ 一律忽略，不嵌图

    def handle_endtag(self, tag):
        if tag in ("h2", "h3", "p"):
            self.current = None
        elif tag == "strong":
            self.bold = False
        elif tag in ("td", "th"):
            self.in_cell = False
            self.cur_row.append("".join(self.cell_buffer))
            self.cell_buffer = []
        elif tag == "tr":
            self.table_rows.append(self.cur_row)
        elif tag == "table":
            self._flush_table()
            self.in_table = False

    def handle_data(self, data):
        if self.in_table and not self.in_cell:
            return
        # 去掉图片占位符
        text = data.replace("__IMG__", "")
        self._add_text(text)

    def _flush_table(self):
        if not self.table_rows:
            return
        ncols = max((len(r) for r in self.table_rows), default=0)
        t = self.doc.add_table(rows=len(self.table_rows), cols=ncols)
        try:
            t.style = "Table Grid"
        except Exception:
            pass
        for i, row in enumerate(self.table_rows):
            cells = t.rows[i].cells
            for j in range(ncols):
                cells[j].text = row[j] if j < len(row) else ""


def set_cjk_font(doc, font="Microsoft YaHei"):
    style = doc.styles["Normal"]
    style.font.name = font
    style.font.size = Pt(11)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(__import__("docx").oxml.ns.qn("w:eastAsia"), font)


added = 0
skipped = 0
for art in zh_articles:
    img_rel = art["img_rel"]
    if img_rel in log:
        print(f"[跳过] 已生成：{img_rel}")
        skipped += 1
        continue

    title = art["title"]
    html = art["html"]
    slug = sanitize(title)

    # 1) Word（纯文字）
    doc = Document()
    set_cjk_font(doc)
    doc.add_heading(title, level=1)
    parser = TextHTMLToDocx(doc)
    parser.feed(html)
    if parser.truncated:
        print(f"  [warn] 中文正文超过 {parser.MAX_CHARS} 字，已截断至上限")
    docx_path = os.path.join(RUN_DIR, f"{slug}.docx")
    doc.save(docx_path)

    # 2) 配套图片文件（从 WordPress 媒体库精确下载，保证与线上文章一致，避免本地同名撞车）
    img_note = ""
    img_dst = None
    media_id = MEDIA_MAP.get(img_rel)
    if media_id:
        b64, ext = get_image_b64(media_id)
        if b64:
            img_dst = os.path.join(RUN_DIR, f"{slug}.{ext}")
            with open(img_dst, "wb") as wf:
                wf.write(base64.b64decode(b64))
            img_note = f"（配套产品图见同目录图片文件：{os.path.basename(img_dst)}）"
    if not img_dst:
        img_note = "（未找到配套图片文件）"

    # 图片说明行附加到 word 末尾
    if img_note:
        p = doc.add_paragraph()
        r = p.add_run(img_note)
        r.italic = True
        r.font.size = Pt(9)
        doc.save(docx_path)

    log[img_rel] = {"date": RUN_DATE, "docx": os.path.relpath(docx_path, BASE),
                    "image": os.path.basename(img_dst) if img_dst else None}
    added += 1
    print(f"[生成] {RUN_DATE}/{slug}.docx" + (f" + 图片 {os.path.basename(img_dst)}" if img_dst else "（无图）"))

json.dump(log, open(LOG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"\n完成：新增 {added} 篇，跳过 {skipped} 篇。目录：{RUN_DIR}")
