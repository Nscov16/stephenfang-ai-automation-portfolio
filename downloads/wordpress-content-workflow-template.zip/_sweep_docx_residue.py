# -*- coding: utf-8 -*-
"""
_sweep_docx_residue.py — 深度扫描 docx，找出「嵌入图片 / 残留引用」问题（可移植）。

检查项：
  - 嵌入图片：word/media/* 或 <w:drawing>/<a:blip>/<w:pict>/<v:imagedata>
  - 文本残留：@image#N: 标记、Clipboard_Screenshot、裸文件名（clean.png 等）
  - 中文残留（若目标是英文-only 存档）

用法（BASE 自动推导）：
  python _sweep_docx_residue.py            # 扫描 output/bilingual + output/zhongqi
  python _sweep_docx_residue.py <目录>      # 只扫指定目录
输出 [OK]/[ISSUE] 每行一个文件，最后给出总问题数。
"""
import os, json, zipfile, re, sys
from docx import Document

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = HERE

TARGETS = sys.argv[1:] if len(sys.argv) > 1 else [
    os.path.join(BASE, "output", "bilingual"),
    os.path.join(BASE, "output", "zhongqi"),
]


def has_cjk(s):
    return any('\u4e00' <= c <= '\u9fff' for c in s)


def deep_inspect(path):
    z = zipfile.ZipFile(path)
    media = [n for n in z.namelist() if n.startswith('word/media/')]
    doc = Document(path)
    issues = []
    for i, p in enumerate(doc.paragraphs):
        for j, r in enumerate(p.runs):
            for elem in r.element.iter():
                tag = elem.tag.split('}')[-1]
                if tag in ('drawing', 'blip', 'imagedata', 'pict'):
                    issues.append(f"para#{i} run#{j} has <{tag}>")
                    break
            if r.text:
                t = r.text
                if re.search(r'@image#\d+:', t) or 'Clipboard_Screenshot' in t:
                    issues.append(f"para#{i} run#{j} text residue: {t[:120]!r}")
                if 'clean.png' in t.lower():
                    issues.append(f"para#{i} run#{j} text clean.png: {t[:120]!r}")
    body_xml = doc.element.xml
    extra = []
    if re.search(r'@image#\d+:', body_xml):
        extra.append("body XML contains @image#N: marker")
    if 'Clipboard_Screenshot' in body_xml:
        extra.append("body XML mentions Clipboard_Screenshot")
    if 'clean.png' in body_xml.lower():
        extra.append("body XML mentions clean.png")
    return media, issues, extra, len(doc.paragraphs), doc


print("=" * 70)
print("DEEP SWEEP — find embedded media AND any stray text/XML residues")
print("=" * 70)
hit_total = 0
for base in TARGETS:
    if not os.path.isdir(base):
        print(f"[SKIP] 目录不存在：{base}")
        continue
    for root, _, files in os.walk(base):
        for fn in sorted(files):
            if not fn.endswith('.docx'):
                continue
            p = os.path.join(root, fn)
            media, issues, extra, nparas, doc = deep_inspect(p)
            rel = os.path.relpath(p, base)
            n_zh = sum(1 for x in doc.paragraphs if has_cjk(x.text))
            if media or issues or extra:
                hit_total += 1
                print(f"\n[ISSUE] {base}/{rel}")
                print(f"  media_files={len(media)}  paragraphs={nparas}  cjk_paras={n_zh}")
                for m in media:
                    print(f"    MEDIA: {m}")
                for it in issues:
                    print(f"    PARA-ISSUE: {it}")
                for it in extra:
                    print(f"    XML-ISSUE:  {it}")
            else:
                print(f"[OK] {base}/{rel} (paras={nparas}, zh={n_zh})")
print(f"\n=== Files with issues: {hit_total} ===")
